<?php /*%%SmartyHeaderCode:9112544156bfac3d89f207-51585095%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '766374aaff367efb5a4349b1cea36d1f20c1fa76' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/socialsharing/views/templates/hook/socialsharing_header.tpl',
      1 => 1455401369,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9112544156bfac3d89f207-51585095',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb261e048b4_86195622',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb261e048b4_86195622')) {function content_56bfb261e048b4_86195622($_smarty_tpl) {?><meta property="og:type" content="product" />
<meta property="og:url" content="http://nfsolucoesdigitais.com.br/loja/inicio/1-ricohmpc3300.html" />
<meta property="og:title" content="RICOH MPC3300 - NF Soluções Digitais" />
<meta property="og:site_name" content="NF Soluções Digitais" />
<meta property="og:description" content="Impressora RICOH" />
<meta property="og:image" content="http://nfsolucoesdigitais.com.br/loja/33-large_default/ricohmpc3300.jpg" />
<meta property="product:pretax_price:amount" content="18400" />
<meta property="product:pretax_price:currency" content="BRL" />
<meta property="product:price:amount" content="18400" />
<meta property="product:price:currency" content="BRL" />
<meta property="product:weight:value" content="100.000000" />
<meta property="product:weight:units" content="kg" />
<?php }} ?>
