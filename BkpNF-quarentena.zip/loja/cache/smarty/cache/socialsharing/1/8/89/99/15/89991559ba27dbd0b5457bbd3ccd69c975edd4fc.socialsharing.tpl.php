<?php /*%%SmartyHeaderCode:138869756956bfac3e38f8d4-25854004%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '89991559ba27dbd0b5457bbd3ccd69c975edd4fc' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/socialsharing/views/templates/hook/socialsharing.tpl',
      1 => 1455401369,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '138869756956bfac3e38f8d4-25854004',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb2622ec1e0_20265291',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb2622ec1e0_20265291')) {function content_56bfb2622ec1e0_20265291($_smarty_tpl) {?>
	<p class="socialsharing_product list-inline no-print">
					<button data-type="twitter" type="button" class="btn btn-default btn-twitter social-sharing">
				<i class="icon-twitter"></i> Tweet
				<!-- <img src="http://nfsolucoesdigitais.com.br/loja/modules/socialsharing/img/twitter.gif" alt="Tweet" /> -->
			</button>
							<button data-type="facebook" type="button" class="btn btn-default btn-facebook social-sharing">
				<i class="icon-facebook"></i> Share
				<!-- <img src="http://nfsolucoesdigitais.com.br/loja/modules/socialsharing/img/facebook.gif" alt="Facebook Like" /> -->
			</button>
							<button data-type="google-plus" type="button" class="btn btn-default btn-google-plus social-sharing">
				<i class="icon-google-plus"></i> Google+
				<!-- <img src="http://nfsolucoesdigitais.com.br/loja/modules/socialsharing/img/google.gif" alt="Google Plus" /> -->
			</button>
							<button data-type="pinterest" type="button" class="btn btn-default btn-pinterest social-sharing">
				<i class="icon-pinterest"></i> Pinterest
				<!-- <img src="http://nfsolucoesdigitais.com.br/loja/modules/socialsharing/img/pinterest.gif" alt="Pinterest" /> -->
			</button>
			</p>
<?php }} ?>
