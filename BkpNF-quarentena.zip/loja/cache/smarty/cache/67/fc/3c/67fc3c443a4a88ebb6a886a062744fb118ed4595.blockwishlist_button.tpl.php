<?php /*%%SmartyHeaderCode:113239241756bfaa42956c49-67845406%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '67fc3c443a4a88ebb6a886a062744fb118ed4595' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockwishlist/blockwishlist_button.tpl',
      1 => 1455299876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '113239241756bfaa42956c49-67845406',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb13512f8a2_08565586',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb13512f8a2_08565586')) {function content_56bfb13512f8a2_08565586($_smarty_tpl) {?>

	
            <span class="wrap_bg">
            <i class="icon-heart icon-0x icon-mar-lr2"></i>
            <span class="wrap_text">Adicionar à lista</span>
            </span>
	<?php }} ?>
