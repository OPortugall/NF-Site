<?php /*%%SmartyHeaderCode:104996548456bfaa4264be35-08912643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b1b9a122849f1a37398937471d19722d78dd900a' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/ptsfeaturedproductslider/ptsfeaturedproductslider.tpl',
      1 => 1455299877,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '104996548456bfaa4264be35-08912643',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb161cc3524_34264421',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb161cc3524_34264421')) {function content_56bfb161cc3524_34264421($_smarty_tpl) {?><div class="pts-featured-product-slider">
    <div class="container">
        <div class="row">
	<div class="pts-featured-product-slider-title"><h2>Produtos Populares</h2></div>
			<ul class="bxslider">
							<li class=" feature-productslider-item ajax_block_product first_item last_item_of_line ">
					<div class="left-block">	
                                        <a href="http://nfsolucoesdigitais.com.br/loja/inicio/1-ricohmpc3300.html" title="RICOH MPC3300" class="product_image">
                                                                                            <span class="hover-image"><img class="replace-2x img-responsive" src="http://nfsolucoesdigitais.com.br/loja/33-large_default/ricohmpc3300.jpg" alt="RICOH MPC3300" title="RICOH MPC3300" /></span>
                                                                                        <img src="http://nfsolucoesdigitais.com.br/loja/33-large_default/ricohmpc3300.jpg"  alt="RICOH MPC3300" />
                                        </a>
                                        
					                                            <div class="button-container fly_3 clearfix">
                                                							<a class="quick-view" href="http://nfsolucoesdigitais.com.br/loja/inicio/1-ricohmpc3300.html" rel="http://nfsolucoesdigitais.com.br/loja/inicio/1-ricohmpc3300.html">
                                                            <span class="wrap_bg">
                                                            <i class="icon-eye-open icon-0x icon-mar-lr2"></i>
                                                            <span class="wrap_text">visão rápida</span>
                                                            </span>
							</a>
						                                                
                                                                                                <a class="addToWishlist wishlistProd_1" href="#" rel="nofollow" onclick="WishlistCart('wishlist_block_list', 'add', '1', false, 1); return false;">
	
            <span class="wrap_bg">
            <i class="icon-heart icon-0x icon-mar-lr2"></i>
            <span class="wrap_text">Adicionar à lista</span>
            </span>
	</a>
                                                																								<a class="exclusive ajax_add_to_cart_button " href="http://nfsolucoesdigitais.com.br/loja/carrinho?add=1&amp;id_product=1&amp;token=b0cd11ee6d19f792a6546dbf9d415722" rel="nofollow" title="Add to cart" data-id-product="1">
                                                                            <span class="wrap_bg">
                                                                        <i class="icon-shopping-cart icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text">Adicionar</span>
                                                                    </span>
									</a>
														
													                                                
                                               
                                            </div>
                                    </div>
                                    <div class="right-block">
					<h5 class="s_title_block"><a href="http://nfsolucoesdigitais.com.br/loja/inicio/1-ricohmpc3300.html" title="RICOH MPC3300">RICOH MPC3300</a></h5>
                                                                                <div class="pr-rt">
                                                                                        
                                                                                                    <div class="content_price">
                                                                                                                                <span class="price product-price">
                                                                            R$ 18.400,00                                                                    </span>
                                                                    
                                                                                                                                                                                    </div>
                                                                                                                                        
                                        </div>
                                    </div>
				</li>
							<li class=" feature-productslider-item ajax_block_product item last_item_of_line ">
					<div class="left-block">	
                                        <a href="http://nfsolucoesdigitais.com.br/loja/inicio/2-brother.html" title="IMP Brother" class="product_image">
                                                                                            <span class="hover-image"><img class="replace-2x img-responsive" src="http://nfsolucoesdigitais.com.br/loja/32-large_default/brother.jpg" alt="IMP Brother" title="IMP Brother" /></span>
                                                                                        <img src="http://nfsolucoesdigitais.com.br/loja/32-large_default/brother.jpg"  alt="IMP Brother" />
                                        </a>
                                        
					                                            <div class="button-container fly_3 clearfix">
                                                							<a class="quick-view" href="http://nfsolucoesdigitais.com.br/loja/inicio/2-brother.html" rel="http://nfsolucoesdigitais.com.br/loja/inicio/2-brother.html">
                                                            <span class="wrap_bg">
                                                            <i class="icon-eye-open icon-0x icon-mar-lr2"></i>
                                                            <span class="wrap_text">visão rápida</span>
                                                            </span>
							</a>
						                                                
                                                                                                <a class="addToWishlist wishlistProd_2" href="#" rel="nofollow" onclick="WishlistCart('wishlist_block_list', 'add', '2', false, 1); return false;">

	
            <span class="wrap_bg">
            <i class="icon-heart icon-0x icon-mar-lr2"></i>
            <span class="wrap_text">Adicionar à lista</span>
            </span>
	</a>
                                                																								<a class="exclusive ajax_add_to_cart_button " href="http://nfsolucoesdigitais.com.br/loja/carrinho?add=1&amp;id_product=2&amp;token=b0cd11ee6d19f792a6546dbf9d415722" rel="nofollow" title="Add to cart" data-id-product="2">
                                                                            <span class="wrap_bg">
                                                                        <i class="icon-shopping-cart icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text">Adicionar</span>
                                                                    </span>
									</a>
														
													                                                
                                               
                                            </div>
                                    </div>
                                    <div class="right-block">
					<h5 class="s_title_block"><a href="http://nfsolucoesdigitais.com.br/loja/inicio/2-brother.html" title="IMP Brother">IMP Brother</a></h5>
                                                                                <div class="pr-rt">
                                                                                        
                                                                                                    <div class="content_price">
                                                                                                                                <span class="price product-price">
                                                                            R$ 4.800,00                                                                    </span>
                                                                    
                                                                                                                                                                                    </div>
                                                                                                                                        
                                        </div>
                                    </div>
				</li>
							<li class=" feature-productslider-item ajax_block_product item last_item_of_line ">
					<div class="left-block">	
                                        <a href="http://nfsolucoesdigitais.com.br/loja/inicio/3-mpc3501.html" title="RICOH MPC3501" class="product_image">
                                                                                            <span class="hover-image"><img class="replace-2x img-responsive" src="http://nfsolucoesdigitais.com.br/loja/34-large_default/mpc3501.jpg" alt="RICOH MPC3501" title="RICOH MPC3501" /></span>
                                                                                        <img src="http://nfsolucoesdigitais.com.br/loja/34-large_default/mpc3501.jpg"  alt="RICOH MPC3501" />
                                        </a>
                                        
					                                            <div class="button-container fly_3 clearfix">
                                                							<a class="quick-view" href="http://nfsolucoesdigitais.com.br/loja/inicio/3-mpc3501.html" rel="http://nfsolucoesdigitais.com.br/loja/inicio/3-mpc3501.html">
                                                            <span class="wrap_bg">
                                                            <i class="icon-eye-open icon-0x icon-mar-lr2"></i>
                                                            <span class="wrap_text">visão rápida</span>
                                                            </span>
							</a>
						                                                
                                                                                                <a class="addToWishlist wishlistProd_3" href="#" rel="nofollow" onclick="WishlistCart('wishlist_block_list', 'add', '3', false, 1); return false;">

	
            <span class="wrap_bg">
            <i class="icon-heart icon-0x icon-mar-lr2"></i>
            <span class="wrap_text">Adicionar à lista</span>
            </span>
	</a>
                                                																								<a class="exclusive ajax_add_to_cart_button " href="http://nfsolucoesdigitais.com.br/loja/carrinho?add=1&amp;id_product=3&amp;token=b0cd11ee6d19f792a6546dbf9d415722" rel="nofollow" title="Add to cart" data-id-product="3">
                                                                            <span class="wrap_bg">
                                                                        <i class="icon-shopping-cart icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text">Adicionar</span>
                                                                    </span>
									</a>
														
													                                                
                                               
                                            </div>
                                    </div>
                                    <div class="right-block">
					<h5 class="s_title_block"><a href="http://nfsolucoesdigitais.com.br/loja/inicio/3-mpc3501.html" title="RICOH MPC3501">RICOH MPC3501</a></h5>
                                                                                <div class="pr-rt">
                                                                                        
                                                                                                    <div class="content_price">
                                                                                                                                <span class="price product-price">
                                                                            R$ 19.200,00                                                                    </span>
                                                                    
                                                                                                                                                                                    </div>
                                                                                                                                        
                                        </div>
                                    </div>
				</li>
							<li class=" feature-productslider-item ajax_block_product last_item last_item_of_line ">
					<div class="left-block">	
                                        <a href="http://nfsolucoesdigitais.com.br/loja/inicio/4-brother.html" title="IMP RICOH SG3100SNw" class="product_image">
                                                                                            <span class="hover-image"><img class="replace-2x img-responsive" src="http://nfsolucoesdigitais.com.br/loja/27-large_default/brother.jpg" alt="IMP RICOH SG3100SNw" title="IMP RICOH SG3100SNw" /></span>
                                                                                        <img src="http://nfsolucoesdigitais.com.br/loja/27-large_default/brother.jpg"  alt="IMP RICOH SG3100SNw" />
                                        </a>
                                        
					                                            <div class="button-container fly_3 clearfix">
                                                							<a class="quick-view" href="http://nfsolucoesdigitais.com.br/loja/inicio/4-brother.html" rel="http://nfsolucoesdigitais.com.br/loja/inicio/4-brother.html">
                                                            <span class="wrap_bg">
                                                            <i class="icon-eye-open icon-0x icon-mar-lr2"></i>
                                                            <span class="wrap_text">visão rápida</span>
                                                            </span>
							</a>
						                                                
                                                                                                <a class="addToWishlist wishlistProd_4" href="#" rel="nofollow" onclick="WishlistCart('wishlist_block_list', 'add', '4', false, 1); return false;">

	
            <span class="wrap_bg">
            <i class="icon-heart icon-0x icon-mar-lr2"></i>
            <span class="wrap_text">Adicionar à lista</span>
            </span>
	</a>
                                                																								<a class="exclusive ajax_add_to_cart_button " href="http://nfsolucoesdigitais.com.br/loja/carrinho?add=1&amp;id_product=4&amp;token=b0cd11ee6d19f792a6546dbf9d415722" rel="nofollow" title="Add to cart" data-id-product="4">
                                                                            <span class="wrap_bg">
                                                                        <i class="icon-shopping-cart icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text">Adicionar</span>
                                                                    </span>
									</a>
														
													                                                
                                               
                                            </div>
                                    </div>
                                    <div class="right-block">
					<h5 class="s_title_block"><a href="http://nfsolucoesdigitais.com.br/loja/inicio/4-brother.html" title="IMP RICOH SG3100SNw">IMP RICOH SG3100SNw</a></h5>
                                                                                <div class="pr-rt">
                                                                                        
                                                                                                    <div class="content_price">
                                                                                                                                <span class="price product-price">
                                                                            R$ 5.600,00                                                                    </span>
                                                                    
                                                                                                                                                                                    </div>
                                                                                                                                        
                                        </div>
                                    </div>
				</li>
					</ul>
		<script type="text/javascript">
		  $('.pts-featured-product-slider .bxslider').bxSlider({
			auto: 0,
			slideWidth:270,
                        infiniteLoop: false,
			slideMargin: 30,
			minSlides: 1,
			maxSlides: 4,
			speed:  3000,
			pause: 600,
			controls: 1,
			pager: false,
		});
	</script>
    </div>
</div>
</div>



<?php }} ?>
