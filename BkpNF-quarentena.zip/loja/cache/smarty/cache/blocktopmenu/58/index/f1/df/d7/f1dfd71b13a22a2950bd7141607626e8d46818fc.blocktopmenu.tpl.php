<?php /*%%SmartyHeaderCode:98710989556bfaa44342642-26010523%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1dfd71b13a22a2950bd7141607626e8d46818fc' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blocktopmenu/blocktopmenu.tpl',
      1 => 1455299876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '98710989556bfaa44342642-26010523',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb13591d061_59875301',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb13591d061_59875301')) {function content_56bfb13591d061_59875301($_smarty_tpl) {?><?php }} ?>
