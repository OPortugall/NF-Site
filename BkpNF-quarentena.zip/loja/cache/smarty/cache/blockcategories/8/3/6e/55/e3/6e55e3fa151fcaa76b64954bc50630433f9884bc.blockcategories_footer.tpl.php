<?php /*%%SmartyHeaderCode:57845685056bfaa446e6f12-32091800%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6e55e3fa151fcaa76b64954bc50630433f9884bc' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcategories/blockcategories_footer.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
    '60ff4acb20d44e0f57c819c7cb0fb25176dc83d5' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcategories/category-tree-branch.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '57845685056bfaa446e6f12-32091800',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb162603af4_26056636',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb162603af4_26056636')) {function content_56bfb162603af4_26056636($_smarty_tpl) {?>
<!-- Block categories module -->
<section class="blockcategories_footer footer-block col-xs-12 col-sm-2">
	<h4>Categorias</h4>
	<div class="category_footer toggle-footer">
		<div class="list">
			<ul class="tree dhtml">
												
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/18-copiadora" title="">
		Copiadora
	</a>
	</li>

							
																
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/3-impressoras" title="">
		Impressoras
	</a>
			<ul>
												
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/4-coloridas" title="">
		Coloridas
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/8-monocromaticas" title="">
		Monocromáticas
	</a>
	</li>

									</ul>
	</li>

							
																
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/17-multifuncional" title="">
		Multifuncional
	</a>
			<ul>
												
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/19-coloridas" title="">
		Coloridas
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/20-monocromaticas" title="">
		Monocromáticas
	</a>
	</li>

									</ul>
	</li>

							
																
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/12-plotter" title="">
		Plotter
	</a>
			<ul>
												
<li class="last">
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/13-canon" title="">
		Canon
	</a>
	</li>

									</ul>
	</li>

							
																
<li class="last">
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/16-suprimentos" title="">
		Suprimentos
	</a>
			<ul>
												
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/21-chip" title="">
		Chip
	</a>
	</li>

																
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/22-cilindro" title="">
		Cilindro
	</a>
	</li>

																
<li >
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/23-revelador" title="">
		Revelador
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://nfsolucoesdigitais.com.br/loja/24-toner" title="">
		Toner
	</a>
	</li>

									</ul>
	</li>

							
										</ul>
		</div>
	</div> <!-- .category_footer -->
</section>
<!-- /Block categories module -->
<?php }} ?>
