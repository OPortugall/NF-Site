<?php /*%%SmartyHeaderCode:117394613156bfab35439876-94146943%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a87649f1d9202fe2e50e33758debecb068fc7d97' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcategories/blockcategories.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '117394613156bfab35439876-94146943',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb75ee233c7_47596230',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb75ee233c7_47596230')) {function content_56bfb75ee233c7_47596230($_smarty_tpl) {?><?php }} ?>
