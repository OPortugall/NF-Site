<?php /*%%SmartyHeaderCode:121402624156bfaa447f78d7-66621015%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c8d90c9303dcbb026d568d6104370ee974f4005f' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcms/blockcms.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '121402624156bfaa447f78d7-66621015',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb135d8ca70_16459777',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb135d8ca70_16459777')) {function content_56bfb135d8ca70_16459777($_smarty_tpl) {?>
	<!-- MODULE Block footer -->
	<div class="block_various_links f-col col-sm-4 col-md-2 col-sms-6 col-smb-12" id="block_various_links_footer">
		<h4 class="title_block">Informação</h4>
                <div class="block_content">
		<ul>
			<li class="first_item"><a href="http://nfsolucoesdigitais.com.br/loja/preços-em-queda" title="Promoções">Promoções</a></li>			<li class="item"><a href="http://nfsolucoesdigitais.com.br/loja/novos-produtos" title="Novidades">Novidades</a></li>
			<li class="item"><a href="http://nfsolucoesdigitais.com.br/loja/melhores-vendas" title="Mais vendidos">Mais vendidos</a></li>			<!--<li class="item"><a href="http://nfsolucoesdigitais.com.br/loja/lojas" title="Nossas lojas">Nossas lojas</a></li>-->
			<li class="item"><a href="http://nfsolucoesdigitais.com.br/loja/entrar-em-contato-conosco" title="Fale conosco">Fale conosco</a></li>
												<li class="item"><a href="http://nfsolucoesdigitais.com.br/loja/content/3-termos-de-utilizacao" title="Termos de Utiliza&ccedil;&atilde;o">Termos de Utiliza&ccedil;&atilde;o</a></li>
										<li class="last"><a href="http://nfsolucoesdigitais.com.br/loja/mapa do site" title="mapa do site">Mapa do site</a></li>
		</ul>
                </div>
	
	</div>
	<!-- /MODULE Block footer -->
<?php }} ?>
