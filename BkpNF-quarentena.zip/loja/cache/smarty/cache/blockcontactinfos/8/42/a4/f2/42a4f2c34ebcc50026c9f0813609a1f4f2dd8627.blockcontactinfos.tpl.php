<?php /*%%SmartyHeaderCode:34966495056bfaa44aef352-96034743%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '42a4f2c34ebcc50026c9f0813609a1f4f2dd8627' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcontactinfos/blockcontactinfos.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '34966495056bfaa44aef352-96034743',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb1629cd528_91427480',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb1629cd528_91427480')) {function content_56bfb1629cd528_91427480($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos">
	<div>
        <h4>SOBRE NÓS</h4>
        <div class="ft_map">
            <p>A NF Soluções Digitais possui perfis nas principais redes sociais utilizadas por brasileiros.</p>
            <ul class="toggle-footer">
                                    <li>
                        <span class="ci_icon"><i class="icon-map-marker"></i></span>
                    <span class="ci_content">Rua Yoshikatsu IIda, 98 -
Jd. Oriente         
São José dos Campos-SP</span>                    </li>
                                                    <li>
                            <span class="ci_icon"><i class="icon-phone"></i></span>
                            <span class="ci_content">Ligue-nos agora: (12) 3029-3838</span>
                    </li>
                                                    <li>
                            <span class="ci_icon"><i class="icon-envelope-alt"></i></span> 
                            <span class="ci_content">E-mail: <a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%76%65%6e%64%61%73@%6e%66%73%6f%6c%75%63%6f%65%73%64%69%67%69%74%61%69%73.%63%6f%6d.%62%72" >&#x76;&#x65;&#x6e;&#x64;&#x61;&#x73;&#x40;&#x6e;&#x66;&#x73;&#x6f;&#x6c;&#x75;&#x63;&#x6f;&#x65;&#x73;&#x64;&#x69;&#x67;&#x69;&#x74;&#x61;&#x69;&#x73;&#x2e;&#x63;&#x6f;&#x6d;&#x2e;&#x62;&#x72;</a></span>
                    </li>
                            </ul>
        </div>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
