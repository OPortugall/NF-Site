<?php /*%%SmartyHeaderCode:81435196256bfaa44968810-15042355%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '42767df249f59003f7fe1bec6a7625db08117416' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockmyaccountfooter/blockmyaccountfooter.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '81435196256bfaa44968810-15042355',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb135ce0629_04090192',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb135ce0629_04090192')) {function content_56bfb135ce0629_04090192($_smarty_tpl) {?>
<!-- Block myaccount module -->
<div class="myaccount f-col col-sm-4 col-md-2 col-sms-6 col-smb-12">
	<div class="account-inner">
		<h4>Minha Conta</h4>
		<div class="block_content">
			<ul class="bullet">
				<li class="first"><a href="http://nfsolucoesdigitais.com.br/loja/minha-conta" title="Minha Conta" rel="nofollow">Minha Conta</a></li>
				<li><a href="http://nfsolucoesdigitais.com.br/loja/histórico-de-pedidos" title="Lista dos meus pedidos" rel="nofollow">Minhas Compras</a></li>
								<li><a href="http://nfsolucoesdigitais.com.br/loja/nota-do-pedido" title="Lista dos meus créditos" rel="nofollow">Meus créditos</a></li>
				<li><a href="http://nfsolucoesdigitais.com.br/loja/endereços" title="Lista dos meus endereços" rel="nofollow">Meus endereços</a></li>
				<li><a href="http://nfsolucoesdigitais.com.br/loja/identificação" title="Gerenciar minhas informações pessoais" rel="nofollow">Minhas Informações</a></li>
				<li class="last"><a href="http://nfsolucoesdigitais.com.br/loja/login" title="Entrar" rel="nofollow">Entrar</a></li>
				
								
			</ul>
		</div>
	</div>
</div>
<!-- /Block myaccount module -->
<?php }} ?>
