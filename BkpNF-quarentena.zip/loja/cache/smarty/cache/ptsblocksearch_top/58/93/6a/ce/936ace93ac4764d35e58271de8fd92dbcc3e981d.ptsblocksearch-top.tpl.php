<?php /*%%SmartyHeaderCode:74820430856bfaa43b5f159-28433283%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '936ace93ac4764d35e58271de8fd92dbcc3e981d' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/ptsblocksearch-top.tpl',
      1 => 1455299864,
      2 => 'file',
    ),
    'f0b26da3fb1c8c6d1b97b4f20fb61a786bf6d30f' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/ptsblocksearch-instantsearch.tpl',
      1 => 1455299864,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '74820430856bfaa43b5f159-28433283',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb13584c7c6_26678944',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb13584c7c6_26678944')) {function content_56bfb13584c7c6_26678944($_smarty_tpl) {?><!-- block seach mobile -->
<div id="sticky_top">
<!-- Block search module TOP -->
<div id="search_block_top" class="clearfix">
   <div class="pts-search">
    	<form method="get" action="http://nfsolucoesdigitais.com.br/loja/procurar" id="searchbox">
            <input type="hidden" name="controller" value="search" />
                                <input type="hidden" name="orderby" value="position" />
                <input type="hidden" name="orderway" value="desc" />
                <input class="search_query form-control" type="text" id="search_query_top" name="search_query" value="Search..." />
                <button type="submit" name="submit_search" class="btn button-search">
                    <span class="icon-search"></span>
                </button>
    	</form>
    </div>
</div>


    <script type="text/javascript">
    // <![CDATA[
            var width_ac_results = $('#searchbox').width();
            $('document').ready( function() {
                    var ac = $("#search_query_top")
                            .autocomplete(
                                    'http://nfsolucoesdigitais.com.br/loja/procurar', {
                                            minChars: 3,
                                            max: 10,
                                            width: (width_ac_results > 0 ? width_ac_results : 500),
                                            selectFirst: false,
                                            scroll: true,
                                            dataType: "json",
                                            formatItem: function(data, i, max, value, term) {
                                                    return value;
                                            },
                                            parse: function(data) {
                                                    var mytab = new Array();
                                                    for (var i = 0; i < data.length; i++)
                                                        mytab[mytab.length] = { 
                                                            data: data[i], 
                                                            value: '<img alt="'+ data[i].pname +'" src="'+ data[i].image +'"><div class="right-search"><h5>'+ data[i].pname +'</h5><span class="price">'+ data[i].dprice +'</span></div> '
                                                        };
                                                    return mytab;
                                            },
                                            extraParams: {
                                                ajaxSearch: 1,
                                                id_lang: 2,
                                                category_filter: $("#category_filter").val()
                                            }
                                    }
                            )
                            .result(function(event, data, formatted) {
                                    $('#search_query_top').val(data.pname);
                                    document.location.href = data.product_link;
                            });
                            
                            $("#category_filter").change(function() {
                                ac.setOptions({
                                    extraParams: {
                                        ajaxSearch: 1,
                                        id_lang: 2,
                                        category_filter: $("#category_filter").val()
                                    }
                                });
                            });
                              
            });
    // ]]>
    </script>
<script type="text/javascript">
	$('#search_query_top').on('focus', function(){
		    var $this = $(this);
		    if($this.val() == 'Search...'){
			$this.val('');
		    }
		}).on('blur', function(){
		    var $this = $(this);
		    if($this.val() == ''){
			$this.val('Search...');
		    }
		});
</script>
<!-- /Block search module TOP -->
<?php }} ?>
