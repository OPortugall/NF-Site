<?php /*%%SmartyHeaderCode:159852420156bfaa42a311b6-94341718%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'df49bfae422db3571d0dd3bad279a8779dd35fbb' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/productcomments/productcomments_reviews.tpl',
      1 => 1455299877,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '159852420156bfaa42a311b6-94341718',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb1355c8646_93734053',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb1355c8646_93734053')) {function content_56bfb1355c8646_93734053($_smarty_tpl) {?><?php }} ?>
