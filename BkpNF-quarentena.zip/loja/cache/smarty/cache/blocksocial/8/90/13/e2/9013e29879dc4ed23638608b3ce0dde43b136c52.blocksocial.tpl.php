<?php /*%%SmartyHeaderCode:164142311656bfaa44590949-09400256%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9013e29879dc4ed23638608b3ce0dde43b136c52' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blocksocial/blocksocial.tpl',
      1 => 1455299876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '164142311656bfaa44590949-09400256',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb162592ca9_62203903',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb162592ca9_62203903')) {function content_56bfb162592ca9_62203903($_smarty_tpl) {?>
<section id="social_block">
    <h4>Siga-nos</h4>
    <p>A NF Soluções Digitais possui perfis nas principais redes sociais utilizadas por brasileiros.</p>
	<ul>
		 			<li class="facebook">
				<a target="_blank" href="http://www.facebook.com/nf.digitais">
                                    <span> <em class="icon-facebook"> </em></span>
                                    
				</a>
			</li>
		                                        <li class="instagram">
				<a target="_blank" href="#">
                                    <span> <em class="icon-instagram"> </em></span>
                                   
				</a>
			</li>
                                        
		 			<li class="twitter">
				<a target="_blank" href="#">
                                    <span><em class="icon-twitter"> </em></span>
                                  
				</a>
			</li>
		                                       
                                        </ul>
    
</section>

<?php }} ?>
