<?php /*%%SmartyHeaderCode:175834779456bfaa45930536-99349564%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dd80abb6ee12b0ae5d5a2133355995409f67b861' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcontact/nav.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '175834779456bfaa45930536-99349564',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb162a4d018_66033693',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb162a4d018_66033693')) {function content_56bfb162a4d018_66033693($_smarty_tpl) {?></div>
<ul id="header_links">
	<!--<li><a href="http://nfsolucoesdigitais.com.br/loja/entrar-em-contato-conosco" title="Fale Conosco">Fale Conosco</a>
</li>-->
		<li>
            <i class="icon-user"></i>
            <a class="link-myaccount" href="http://nfsolucoesdigitais.com.br/loja/minha-conta" title="Minha conta">Minha conta</a></li>
	
	<li>
               <i class="icon-heart"></i>
               <a class="link-wishlist wishlist_block" href="http://nfsolucoesdigitais.com.br/loja/module/blockwishlist/mywishlist" title="Meus desejos">Meus desejos</a></li>
		<li>
            <i class="icon-shopping-cart"></i>
            <a class="link-mycart" href="http://nfsolucoesdigitais.com.br/loja/pedido" title="Meu carrinho">Meu carrinho</a></li>
	        	<li>
            <i class="icon-check-sign"></i>
            <a class="link-checkout" href="http://nfsolucoesdigitais.com.br/loja/pedido" title="Check-out">Check-out</a></li>
		                         <li class="last">
                             <i class="icon-lock"></i>
                             <a href="http://nfsolucoesdigitais.com.br/loja/minha-conta" title="Ver minha conta de cliente" class="account" rel="nofollow">oi, John DOE! </a>
                             <a class="link-out" href="http://nfsolucoesdigitais.com.br/loja/?mylogout=" title="Sair"  rel="nofollow">Sair</a>
                         </li>
			
</ul><?php }} ?>
