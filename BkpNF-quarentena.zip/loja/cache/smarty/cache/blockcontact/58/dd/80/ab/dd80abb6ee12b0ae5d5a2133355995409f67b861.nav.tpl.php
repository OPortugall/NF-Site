<?php /*%%SmartyHeaderCode:175834779456bfaa45930536-99349564%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dd80abb6ee12b0ae5d5a2133355995409f67b861' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcontact/nav.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '175834779456bfaa45930536-99349564',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb136014769_83717574',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb136014769_83717574')) {function content_56bfb136014769_83717574($_smarty_tpl) {?></div>
<ul id="header_links">
	<!--<li><a href="http://nfsolucoesdigitais.com.br/loja/entrar-em-contato-conosco" title="Fale Conosco">Fale Conosco</a>
</li>-->
		<li>
            <i class="icon-user"></i>
            <a class="link-myaccount" href="http://nfsolucoesdigitais.com.br/loja/minha-conta" title="Minha conta">Minha conta</a></li>
	
	<li>
               <i class="icon-heart"></i>
               <a class="link-wishlist wishlist_block" href="http://nfsolucoesdigitais.com.br/loja/module/blockwishlist/mywishlist" title="Meus desejos">Meus desejos</a></li>
		<li>
            <i class="icon-shopping-cart"></i>
            <a class="link-mycart" href="http://nfsolucoesdigitais.com.br/loja/pedido" title="Meu carrinho">Meu carrinho</a></li>
	        	<li>
            <i class="icon-check-sign"></i>
            <a class="link-checkout" href="http://nfsolucoesdigitais.com.br/loja/pedido" title="Check-out">Check-out</a></li>
					<li class="last">
                            <i class="icon-lock"></i>
                            <a class="link-login" href="http://nfsolucoesdigitais.com.br/loja/minha-conta" title="Entrar"  rel="nofollow">Entrar</a></li>
		
</ul><?php }} ?>
