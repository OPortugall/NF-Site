<?php /*%%SmartyHeaderCode:103085549156bfac3de43ab5-15510577%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '29873f61686bb5e63e5f89f35cb6fd03d7627715' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/ptsproductcates/productscategory.tpl',
      1 => 1455299877,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '103085549156bfac3de43ab5-15510577',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56bfb2621e81b7_88548712',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56bfb2621e81b7_88548712')) {function content_56bfb2621e81b7_88548712($_smarty_tpl) {?>
<div class="clearfix ptsproductcategory">
	<h2 class="ptsproductcategory_h2">3 OUTROS PRODUTOS na mesma categoria</h2>
	
	<div id="ptsproductcategory_list">
                 	<ul class="bxslider">	
                                                               <li >
                                        <a href="http://nfsolucoesdigitais.com.br/loja/inicio/2-brother.html" class="lnk_img" title="IMP Brother">
                                                                                            <span class="hover-image"><img class="replace-2x img-responsive" src="http://nfsolucoesdigitais.com.br/loja/32-large_default/brother.jpg" alt="IMP Brother" title="IMP Brother" /></span>
                                                                                        <img src="http://nfsolucoesdigitais.com.br/loja/32-large_default/brother.jpg" alt="IMP Brother" /></a>
                                        <p class="product_name">
                                                <a href="http://nfsolucoesdigitais.com.br/loja/inicio/2-brother.html" title="IMP Brother">IMP Brother</a>
                                        </p>
                                        
                                                                                <p class="price_display">
                                                <span class="price">R$ 4.800,00</span>
                                        </p>
                                                                                                                                                                                                                                                                                                
                                    </li>
                                                               <li >
                                        <a href="http://nfsolucoesdigitais.com.br/loja/inicio/3-mpc3501.html" class="lnk_img" title="RICOH MPC3501">
                                                                                            <span class="hover-image"><img class="replace-2x img-responsive" src="http://nfsolucoesdigitais.com.br/loja/34-large_default/mpc3501.jpg" alt="RICOH MPC3501" title="RICOH MPC3501" /></span>
                                                                                        <img src="http://nfsolucoesdigitais.com.br/loja/34-large_default/mpc3501.jpg" alt="RICOH MPC3501" /></a>
                                        <p class="product_name">
                                                <a href="http://nfsolucoesdigitais.com.br/loja/inicio/3-mpc3501.html" title="RICOH MPC3501">RICOH MPC3501</a>
                                        </p>
                                        
                                                                                <p class="price_display">
                                                <span class="price">R$ 19.200,00</span>
                                        </p>
                                                                                                                                                                                                                                                                                                
                                    </li>
                                                               <li >
                                        <a href="http://nfsolucoesdigitais.com.br/loja/inicio/4-brother.html" class="lnk_img" title="IMP RICOH SG3100SNw">
                                                                                            <span class="hover-image"><img class="replace-2x img-responsive" src="http://nfsolucoesdigitais.com.br/loja/27-large_default/brother.jpg" alt="IMP RICOH SG3100SNw" title="IMP RICOH SG3100SNw" /></span>
                                                                                        <img src="http://nfsolucoesdigitais.com.br/loja/27-large_default/brother.jpg" alt="IMP RICOH SG3100SNw" /></a>
                                        <p class="product_name">
                                                <a href="http://nfsolucoesdigitais.com.br/loja/inicio/4-brother.html" title="IMP RICOH SG3100SNw">IMP RICOH SG3100SNw</a>
                                        </p>
                                        
                                                                                <p class="price_display">
                                                <span class="price">R$ 5.600,00</span>
                                        </p>
                                                                                                                                                                                                                                                                                                
                                    </li>
                                                </ul>
            </div>
	
	
</div>

<script type="text/javascript">
	  $('#ptsproductcategory_list .bxslider').bxSlider({
		auto: 0,
		slideWidth:218,
		slideMargin: 20,
		minSlides: 1,
		maxSlides: 5,
		speed:  1000,
		pause: 600,
		controls: 1,
		pager: false,
	});
</script><?php }} ?>
