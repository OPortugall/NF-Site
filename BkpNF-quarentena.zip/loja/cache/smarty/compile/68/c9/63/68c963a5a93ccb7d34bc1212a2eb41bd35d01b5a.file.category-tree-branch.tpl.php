<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:14
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/category-tree-branch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2612527856e8a2fe636022-89328386%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '68c963a5a93ccb7d34bc1212a2eb41bd35d01b5a' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/category-tree-branch.tpl',
      1 => 1455299864,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2612527856e8a2fe636022-89328386',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'node' => 0,
    'current_category' => 0,
    'child' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fe67f841_35287627',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fe67f841_35287627')) {function content_56e8a2fe67f841_35287627($_smarty_tpl) {?>
<option value="<?php echo $_smarty_tpl->tpl_vars['node']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['current_category']->value==$_smarty_tpl->tpl_vars['node']->value['id']) {?>selected="selected"<?php }?>>
    <?php echo $_smarty_tpl->tpl_vars['node']->value['prefix'];?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['node']->value['name'], ENT_QUOTES, 'UTF-8', true);?>

</option>
<?php if (count($_smarty_tpl->tpl_vars['node']->value['children'])>0) {?>
    <?php  $_smarty_tpl->tpl_vars['child'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['child']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['node']->value['children']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['child']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['child']->iteration=0;
foreach ($_from as $_smarty_tpl->tpl_vars['child']->key => $_smarty_tpl->tpl_vars['child']->value) {
$_smarty_tpl->tpl_vars['child']->_loop = true;
 $_smarty_tpl->tpl_vars['child']->iteration++;
 $_smarty_tpl->tpl_vars['child']->last = $_smarty_tpl->tpl_vars['child']->iteration === $_smarty_tpl->tpl_vars['child']->total;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['ptsblocksearchTreeBranch']['last'] = $_smarty_tpl->tpl_vars['child']->last;
?>
        <?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['ptsblocksearchTreeBranch']['last']) {?>
            <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['ptsbranche_tpl_path']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('node'=>$_smarty_tpl->tpl_vars['child']->value,'last'=>'true'), 0);?>

        <?php } else { ?>
            <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['ptsbranche_tpl_path']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('node'=>$_smarty_tpl->tpl_vars['child']->value,'last'=>'false'), 0);?>

        <?php }?>
    <?php } ?>
<?php }?>
<?php }} ?>
