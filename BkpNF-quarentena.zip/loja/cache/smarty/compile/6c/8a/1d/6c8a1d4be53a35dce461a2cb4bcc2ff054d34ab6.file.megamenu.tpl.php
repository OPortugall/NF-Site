<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:12
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/ptsmegamenu/megamenu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:168677581756e8a2fcc51e13-23915026%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6c8a1d4be53a35dce461a2cb4bcc2ff054d34ab6' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/ptsmegamenu/megamenu.tpl',
      1 => 1458086411,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '168677581756e8a2fcc51e13-23915026',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'blockCategTree' => 0,
    'isDhtml' => 0,
    'menu_item_mobile' => 0,
    'child' => 0,
    'menu_link_mobile' => 0,
    'megamenu' => 0,
    'effect' => 0,
    'top_offset' => 0,
    'PTS_LANG_RTL' => 0,
    'PTS_SKIN_DEFAULT' => 0,
    'PTS_PANELTOOL' => 0,
    'PTS_COLOR1' => 0,
    'PTS_COLOR2' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fcce1857_12746017',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fcce1857_12746017')) {function content_56e8a2fcce1857_12746017($_smarty_tpl) {?><!-- Block categories module -->
<?php if ($_smarty_tpl->tpl_vars['blockCategTree']->value!='') {?>
    <div class="nav-mobile-container visible-sm visible-xs ">
        <div class="navbar">
            <div id="navbar-inner" class="navbar-inner navbar-inactive">
                <div class="menu-mobile">
                    <a class="btn btn-navbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <span class="brand"><?php echo smartyTranslate(array('s'=>'Menu'),$_smarty_tpl);?>
</span>
                </div>
                <ul id="pts-mobilemenu" class="tree <?php if ($_smarty_tpl->tpl_vars['isDhtml']->value) {?>dhtml<?php }?>  mobilemenu nav-collapse collapse">
                    <?php  $_smarty_tpl->tpl_vars['child'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['child']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['menu_item_mobile']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['child']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['child']->iteration=0;
foreach ($_from as $_smarty_tpl->tpl_vars['child']->key => $_smarty_tpl->tpl_vars['child']->value) {
$_smarty_tpl->tpl_vars['child']->_loop = true;
 $_smarty_tpl->tpl_vars['child']->iteration++;
 $_smarty_tpl->tpl_vars['child']->last = $_smarty_tpl->tpl_vars['child']->iteration === $_smarty_tpl->tpl_vars['child']->total;
 $_smarty_tpl->tpl_vars['smarty']->value['foreach']['blockCategTree']['last'] = $_smarty_tpl->tpl_vars['child']->last;
?>
                        <?php if ($_smarty_tpl->getVariable('smarty')->value['foreach']['blockCategTree']['last']) {?>
                            <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['branche_tpl_path']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('node'=>$_smarty_tpl->tpl_vars['child']->value,'last'=>'true'), 0);?>

                        <?php } else { ?>
                            <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['branche_tpl_path']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('node'=>$_smarty_tpl->tpl_vars['child']->value), 0);?>

                        <?php }?>
                    <?php } ?>
                    <?php echo $_smarty_tpl->tpl_vars['menu_link_mobile']->value;?>

                </ul>
                <script type="text/javascript">
                    // <![CDATA[
                    // we hide the tree only if JavaScript is activated
                    $('div#categories_block_left ul.dhtml').hide();
                    // ]]>
                </script>
            </div>
        </div>
    </div>
<?php }?>
<!-- /Block categories module -->
                <div class="nav-container visible-lg visible-md">
                    <div id="pts_megamenu" class="pts_megamenu">
                        <?php echo $_smarty_tpl->tpl_vars['megamenu']->value;?>

                    </div>
                </div>
<script type="text/javascript">
//<![CDATA[
    var CUSTOMMENU_POPUP_EFFECT = <?php echo $_smarty_tpl->tpl_vars['effect']->value;?>
;
    var CUSTOMMENU_POPUP_TOP_OFFSET = <?php echo $_smarty_tpl->tpl_vars['top_offset']->value;?>
;
    var LANG_RTL = <?php echo $_smarty_tpl->tpl_vars['PTS_LANG_RTL']->value;?>
;
    var CHECK_SKIN = '<?php echo $_smarty_tpl->tpl_vars['PTS_SKIN_DEFAULT']->value;?>
';
    var PANELTOOL = <?php echo $_smarty_tpl->tpl_vars['PTS_PANELTOOL']->value;?>

    if(CHECK_SKIN == "color_comb" && PANELTOOL != 1){
        var COLOR1 = '<?php echo substr($_smarty_tpl->tpl_vars['PTS_COLOR1']->value,1,6);?>
';
        var COLOR2 = '<?php echo substr($_smarty_tpl->tpl_vars['PTS_COLOR2']->value,1,6);?>
';
    }
 //]]>
</script><?php }} ?>
