<?php /* Smarty version Smarty-3.1.19, created on 2017-09-18 01:04:35
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/controllers/localization/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:53525238959bf37c3568ea5-43408868%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cf7fe56a6e662708f47f8c5e77e7516490957495' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/controllers/localization/content.tpl',
      1 => 1455401129,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '53525238959bf37c3568ea5-43408868',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'localization_form' => 0,
    'localization_options' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_59bf37c35ef412_66514717',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59bf37c35ef412_66514717')) {function content_59bf37c35ef412_66514717($_smarty_tpl) {?>

<?php if (isset($_smarty_tpl->tpl_vars['localization_form']->value)) {?><?php echo $_smarty_tpl->tpl_vars['localization_form']->value;?>
<?php }?>
<?php if (isset($_smarty_tpl->tpl_vars['localization_options']->value)) {?><?php echo $_smarty_tpl->tpl_vars['localization_options']->value;?>
<?php }?>
<script type="text/javascript">
	$(document).ready(function() {
		$('#PS_CURRENCY_DEFAULT').change(function(e) {
			alert('Before changing the default currency, we strongly recommend that you enable maintenance mode because any change on default currency requires manual adjustment of the price of each product');
		});
	});
</script><?php }} ?>
