<?php /* Smarty version Smarty-3.1.19, created on 2016-04-05 18:24:54
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/blocknewsletter/views/templates/admin/list_action_viewcustomer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:167357278157041f16d84214-22101368%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '83f5cc79d41a4374cac78cb1e4213965e793ac15' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/blocknewsletter/views/templates/admin/list_action_viewcustomer.tpl',
      1 => 1455401254,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '167357278157041f16d84214-22101368',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'href' => 0,
    'disable' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57041f16dc5be3_24457900',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57041f16dc5be3_24457900')) {function content_57041f16dc5be3_24457900($_smarty_tpl) {?>
<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['href']->value, ENT_QUOTES, 'UTF-8', true);?>
" class="edit btn btn-default <?php if ($_smarty_tpl->tpl_vars['disable']->value) {?>disabled<?php }?>" title="<?php echo $_smarty_tpl->tpl_vars['action']->value;?>
" >
	<i class="icon-search-plus"></i> <?php echo $_smarty_tpl->tpl_vars['action']->value;?>

</a><?php }} ?>
