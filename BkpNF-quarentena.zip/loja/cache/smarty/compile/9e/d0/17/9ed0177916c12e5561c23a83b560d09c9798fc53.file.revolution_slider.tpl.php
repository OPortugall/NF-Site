<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:12
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/revsliderprestashop/views/templates/front/revolution_slider.tpl" */ ?>
<?php /*%%SmartyHeaderCode:194607645156e8a2fc6c4c56-20234933%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ed0177916c12e5561c23a83b560d09c9798fc53' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/revsliderprestashop/views/templates/front/revolution_slider.tpl',
      1 => 1455299878,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '194607645156e8a2fc6c4c56-20234933',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'revhome' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fc7215e2_35347792',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fc7215e2_35347792')) {function content_56e8a2fc7215e2_35347792($_smarty_tpl) {?> <?php echo $_smarty_tpl->tpl_vars['revhome']->value;?>
<?php }} ?>
