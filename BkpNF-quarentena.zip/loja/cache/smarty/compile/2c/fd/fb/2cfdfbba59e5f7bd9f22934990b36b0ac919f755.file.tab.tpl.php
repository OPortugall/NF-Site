<?php /* Smarty version Smarty-3.1.19, created on 2016-03-16 13:33:00
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/productcomments//tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:45286181256e97cac81ad79-92311249%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2cfdfbba59e5f7bd9f22934990b36b0ac919f755' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/productcomments//tab.tpl',
      1 => 1455299877,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '45286181256e97cac81ad79-92311249',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e97cac82a627_83221899',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e97cac82a627_83221899')) {function content_56e97cac82a627_83221899($_smarty_tpl) {?>

<li><a href="#idTab5" class="idTabHrefShort"><?php echo smartyTranslate(array('s'=>'Reviews','mod'=>'productcomments'),$_smarty_tpl);?>
</a></li><?php }} ?>
