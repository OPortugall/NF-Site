<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:14
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/ptsblocksearch-instantsearch.tpl" */ ?>
<?php /*%%SmartyHeaderCode:83817176856e8a2fe70d8a4-50665804%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f0b26da3fb1c8c6d1b97b4f20fb61a786bf6d30f' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/ptsblocksearch-instantsearch.tpl',
      1 => 1455299864,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '83817176856e8a2fe70d8a4-50665804',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'instantsearch' => 0,
    'ptsblocksearch_type' => 0,
    'search_ssl' => 0,
    'link' => 0,
    'cookie' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fe76f710_42212675',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fe76f710_42212675')) {function content_56e8a2fe76f710_42212675($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['instantsearch']->value) {?>
	<script type="text/javascript">
	// <![CDATA[
		function tryToCloseInstantSearch() {
			if ($('#old_center_column').length > 0)
			{
				$('#center_column').remove();
				$('#old_center_column').attr('id', 'center_column');
				$('#center_column').show();
				return false;
			}
		}
		
		instantSearchQueries = new Array();
		function stopInstantSearchQueries(){
			for(i=0;i<instantSearchQueries.length;i++) {
				instantSearchQueries[i].abort();
			}
			instantSearchQueries = new Array();
		}
		
		$("#search_query_<?php echo $_smarty_tpl->tpl_vars['ptsblocksearch_type']->value;?>
").keyup(function(){
			if($(this).val().length > 0){
				stopInstantSearchQueries();
				instantSearchQuery = $.ajax({
					url: '<?php if ($_smarty_tpl->tpl_vars['search_ssl']->value==1) {?><?php echo addslashes($_smarty_tpl->tpl_vars['link']->value->getPageLink('search',true));?>
<?php } else { ?><?php echo addslashes($_smarty_tpl->tpl_vars['link']->value->getPageLink('search'));?>
<?php }?>',
					data: {
						instantSearch: 1,
						id_lang: <?php echo $_smarty_tpl->tpl_vars['cookie']->value->id_lang;?>
,
						q: $(this).val(),
						category_filter: $("#category_filter").val()
					},
					dataType: 'html',
					type: 'POST',
					success: function(data){
						if($("#search_query_<?php echo $_smarty_tpl->tpl_vars['ptsblocksearch_type']->value;?>
").val().length > 0)
						{
							tryToCloseInstantSearch();
							$('#center_column').attr('id', 'old_center_column');
							$('#old_center_column').after('<div id="center_column" class="' + $('#old_center_column').attr('class') + '">'+data+'</div>');
							$('#old_center_column').hide();
							// Button override
							ajaxCart.overrideButtonsInThePage();
							$("#instant_search_results a.close").click(function() {
								$("#search_query_<?php echo $_smarty_tpl->tpl_vars['ptsblocksearch_type']->value;?>
").val('');
								return tryToCloseInstantSearch();
							});
							return false;
						}
						else
							tryToCloseInstantSearch();
					}
				});
				instantSearchQueries.push(instantSearchQuery);
			}
			else
				tryToCloseInstantSearch();
		});
	// ]]>
	</script>
<?php }?>


    <script type="text/javascript">
    // <![CDATA[
            var width_ac_results = $('#searchbox').width();
            $('document').ready( function() {
                    var ac = $("#search_query_<?php echo $_smarty_tpl->tpl_vars['ptsblocksearch_type']->value;?>
")
                            .autocomplete(
                                    '<?php if ($_smarty_tpl->tpl_vars['search_ssl']->value==1) {?><?php echo addslashes($_smarty_tpl->tpl_vars['link']->value->getPageLink('search',true));?>
<?php } else { ?><?php echo addslashes($_smarty_tpl->tpl_vars['link']->value->getPageLink('search'));?>
<?php }?>', {
                                            minChars: 3,
                                            max: 10,
                                            width: (width_ac_results > 0 ? width_ac_results : 500),
                                            selectFirst: false,
                                            scroll: true,
                                            dataType: "json",
                                            formatItem: function(data, i, max, value, term) {
                                                    return value;
                                            },
                                            parse: function(data) {
                                                    var mytab = new Array();
                                                    for (var i = 0; i < data.length; i++)
                                                        mytab[mytab.length] = { 
                                                            data: data[i], 
                                                            value: '<img alt="'+ data[i].pname +'" src="'+ data[i].image +'"><div class="right-search"><h5>'+ data[i].pname +'</h5><span class="price">'+ data[i].dprice +'</span></div> '
                                                        };
                                                    return mytab;
                                            },
                                            extraParams: {
                                                ajaxSearch: 1,
                                                id_lang: <?php echo $_smarty_tpl->tpl_vars['cookie']->value->id_lang;?>
,
                                                category_filter: $("#category_filter").val()
                                            }
                                    }
                            )
                            .result(function(event, data, formatted) {
                                    $('#search_query_<?php echo $_smarty_tpl->tpl_vars['ptsblocksearch_type']->value;?>
').val(data.pname);
                                    document.location.href = data.product_link;
                            });
                            
                            $("#category_filter").change(function() {
                                ac.setOptions({
                                    extraParams: {
                                        ajaxSearch: 1,
                                        id_lang: <?php echo $_smarty_tpl->tpl_vars['cookie']->value->id_lang;?>
,
                                        category_filter: $("#category_filter").val()
                                    }
                                });
                            });
                              
            });
    // ]]>
    </script><?php }} ?>
