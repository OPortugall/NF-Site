<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:16
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockuserinfo/nav.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11373613556e8a3001459d5-11247979%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4acc2bb61ba735aa1dcff972e98437585d484adb' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockuserinfo/nav.tpl',
      1 => 1455299876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11373613556e8a3001459d5-11247979',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a300149539_23886372',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a300149539_23886372')) {function content_56e8a300149539_23886372($_smarty_tpl) {?><!-- Block user information module NAV  -->

<!-- /Block usmodule NAV -->
<?php }} ?>
