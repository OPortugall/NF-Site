<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:15
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsscroll/ptsscroll.tpl" */ ?>
<?php /*%%SmartyHeaderCode:143744694656e8a2ff988b77-09384149%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5fa80a4eee1f38b810c305b4bbaf5857b9fc2496' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsscroll/ptsscroll.tpl',
      1 => 1455299865,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '143744694656e8a2ff988b77-09384149',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2ff98c925_06305130',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2ff98c925_06305130')) {function content_56e8a2ff98c925_06305130($_smarty_tpl) {?><div class="back-top"><a href= "#" class="mypresta_scrollup hidden-phone"></a></div><?php }} ?>
