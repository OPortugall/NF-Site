<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:14
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/ptsblocksearch-top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:153396545856e8a2fe6b2852-63285496%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '936ace93ac4764d35e58271de8fd92dbcc3e981d' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsblocksearch/ptsblocksearch-top.tpl',
      1 => 1455299864,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '153396545856e8a2fe6b2852-63285496',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'link' => 0,
    'PTS_SHOWCAT' => 0,
    'category_html' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fe6dbdf4_07969954',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fe6dbdf4_07969954')) {function content_56e8a2fe6dbdf4_07969954($_smarty_tpl) {?>
<!-- block seach mobile -->
<div id="sticky_top">
<!-- Block search module TOP -->
<div id="search_block_top" class="clearfix">
   <div class="pts-search">
    	<form method="get" action="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getPageLink('search'), ENT_QUOTES, 'UTF-8', true);?>
" id="searchbox">
            <input type="hidden" name="controller" value="search" />
                <?php if ($_smarty_tpl->tpl_vars['PTS_SHOWCAT']->value==1) {?>
                <div class="input-group-btn">
                    <?php echo $_smarty_tpl->tpl_vars['category_html']->value;?>

                    <i class="icon-angle-down"></i>
                </div>
                <?php }?>
                <input type="hidden" name="orderby" value="position" />
                <input type="hidden" name="orderway" value="desc" />
                <input class="search_query form-control" type="text" id="search_query_top" name="search_query" value="<?php echo smartyTranslate(array('s'=>'Search...','mod'=>'ptsblocksearch'),$_smarty_tpl);?>
" />
                <button type="submit" name="submit_search" class="btn button-search">
                    <span class="icon-search"></span>
                </button>
    	</form>
    </div>
</div>
<?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['self']->value)."/ptsblocksearch-instantsearch.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<script type="text/javascript">
	$('#search_query_top').on('focus', function(){
		    var $this = $(this);
		    if($this.val() == '<?php echo smartyTranslate(array('s'=>'Search...','mod'=>'blocksearch'),$_smarty_tpl);?>
'){
			$this.val('');
		    }
		}).on('blur', function(){
		    var $this = $(this);
		    if($this.val() == ''){
			$this.val('<?php echo smartyTranslate(array('s'=>'Search...','mod'=>'blocksearch'),$_smarty_tpl);?>
');
		    }
		});
</script>
<!-- /Block search module TOP -->
<?php }} ?>
