<?php /* Smarty version Smarty-3.1.19, created on 2016-09-13 17:07:25
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blocklayered/blocklayered-no-products.tpl" */ ?>
<?php /*%%SmartyHeaderCode:82812346257d84e6d633a12-21879723%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '81935211619fc5af42f0cd625b7c8300bc98ca00' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blocklayered/blocklayered-no-products.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '82812346257d84e6d633a12-21879723',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57d84e6d6d5403_78309540',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57d84e6d6d5403_78309540')) {function content_57d84e6d6d5403_78309540($_smarty_tpl) {?>
<div class="product_list">
	<p class="alert alert-warning"><?php echo smartyTranslate(array('s'=>'There are no products.','mod'=>'blocklayered'),$_smarty_tpl);?>
</p>
</div>
<?php }} ?>
