<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:15
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blocksocial/blocksocial.tpl" */ ?>
<?php /*%%SmartyHeaderCode:167912907956e8a2ff1ea4e0-06111143%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9013e29879dc4ed23638608b3ce0dde43b136c52' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blocksocial/blocksocial.tpl',
      1 => 1455299876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '167912907956e8a2ff1ea4e0-06111143',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'facebook_url' => 0,
    'instagram_url' => 0,
    'twitter_url' => 0,
    'rss_url' => 0,
    'pinterest_url' => 0,
    'google_plus_url' => 0,
    'vimeo_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2ff2c34a5_45304789',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2ff2c34a5_45304789')) {function content_56e8a2ff2c34a5_45304789($_smarty_tpl) {?>

<section id="social_block">
    <h4><?php echo smartyTranslate(array('s'=>'Follow us','mod'=>'blocksocial'),$_smarty_tpl);?>
</h4>
    <p><?php echo smartyTranslate(array('s'=>'A NF Soluções Digitais possui perfis nas principais redes sociais utilizadas por brasileiros.','mod'=>'blocksocial'),$_smarty_tpl);?>
</p>
	<ul>
		 <?php if (isset($_smarty_tpl->tpl_vars['facebook_url']->value)&&$_smarty_tpl->tpl_vars['facebook_url']->value!='') {?>
			<li class="facebook">
				<a target="_blank" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['facebook_url']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                    <span> <em class="icon-facebook"> </em></span>
                                    
				</a>
			</li>
		<?php }?>
                <?php if (isset($_smarty_tpl->tpl_vars['instagram_url']->value)&&$_smarty_tpl->tpl_vars['instagram_url']->value!='') {?>
                        <li class="instagram">
				<a target="_blank" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['instagram_url']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                    <span> <em class="icon-instagram"> </em></span>
                                   
				</a>
			</li>
                <?php }?>
                        
		 <?php if (isset($_smarty_tpl->tpl_vars['twitter_url']->value)&&$_smarty_tpl->tpl_vars['twitter_url']->value!='') {?>
			<li class="twitter">
				<a target="_blank" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['twitter_url']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                    <span><em class="icon-twitter"> </em></span>
                                  
				</a>
			</li>
		<?php }?>
                <?php if (isset($_smarty_tpl->tpl_vars['rss_url']->value)&&$_smarty_tpl->tpl_vars['rss_url']->value!='') {?>  
                        <li class="dribble">
				<a target="_blank" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['rss_url']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                    <span>  <em class="icon-dribble"> </em></span>
                                    
				</a>
			</li>
                <?php }?>
               <?php if (isset($_smarty_tpl->tpl_vars['pinterest_url']->value)&&$_smarty_tpl->tpl_vars['pinterest_url']->value!='') {?>
                        <li class="pinterest">
                                <a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['pinterest_url']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                    <span> <em class="icon-pinterest"> </em></span>
                                   
                                </a>
                        </li>
                <?php }?>        
                <?php if (isset($_smarty_tpl->tpl_vars['google_plus_url']->value)&&$_smarty_tpl->tpl_vars['google_plus_url']->value!='') {?>
                        <li class="google-plus">
                                <a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['google_plus_url']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                    <span> <em class="icon-google-plus"> </em></span>
                                    
                                </a>
                        </li>
                <?php }?>
                <?php if (isset($_smarty_tpl->tpl_vars['vimeo_url']->value)&&$_smarty_tpl->tpl_vars['vimeo_url']->value!='') {?>
                        <li class="vimeo">
                            <a class="_blank" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['vimeo_url']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                <span><em class="icon-vimeo"> </em></span>
                                               
                            </a>
                        </li>
        <?php }?>
        </ul>
    
</section>

<?php }} ?>
