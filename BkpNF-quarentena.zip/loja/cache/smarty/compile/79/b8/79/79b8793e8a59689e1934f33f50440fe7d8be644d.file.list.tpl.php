<?php /* Smarty version Smarty-3.1.19, created on 2016-04-05 18:17:41
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/helpers/list/list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:211780233857041d65d152b4-87145365%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '79b8793e8a59689e1934f33f50440fe7d8be644d' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/helpers/list/list.tpl',
      1 => 1455401134,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '211780233857041d65d152b4-87145365',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'content' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57041d65d2e908_67334719',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57041d65d2e908_67334719')) {function content_57041d65d2e908_67334719($_smarty_tpl) {?>
<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>

<?php }} ?>
