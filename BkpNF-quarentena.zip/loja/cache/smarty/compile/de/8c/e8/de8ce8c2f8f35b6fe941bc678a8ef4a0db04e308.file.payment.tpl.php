<?php /* Smarty version Smarty-3.1.19, created on 2016-06-08 19:29:32
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/pagseguro//views/templates/hook/payment.tpl" */ ?>
<?php /*%%SmartyHeaderCode:103468471657588e3c513af9-89161323%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'de8ce8c2f8f35b6fe941bc678a8ef4a0db04e308' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/pagseguro//views/templates/hook/payment.tpl',
      1 => 1455406863,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '103468471657588e3c513af9-89161323',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'version' => 0,
    'image' => 0,
    'action_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57588e3c5b5304_97260488',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57588e3c5b5304_97260488')) {function content_57588e3c5b5304_97260488($_smarty_tpl) {?>

<?php if ($_smarty_tpl->tpl_vars['version']->value==false) {?>
<div class="row">
	<div class="col-xs-12 col-md-6">
		<p class="payment_module">
		    <a style="background: url(<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['image']->value, ENT_QUOTES, 'UTF-8', true);?>
) 1% 50% no-repeat;" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['action_url']->value, ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo smartyTranslate(array('s'=>'CLIQUE AQUI PARA FINALIZAR SUA COMPRA !!!','mod'=>'pagseguro'),$_smarty_tpl);?>
">
			<?php echo smartyTranslate(array('s'=>'  ','mod'=>'pagseguro'),$_smarty_tpl);?>

		    </a>
		</p> 
	</div>
</div>
<?php } else { ?>
<p class="payment_module">
    <a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['action_url']->value, ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo smartyTranslate(array('s'=>'Pague com PagSeguro e parcele em até 18 vezes','mod'=>'pagseguro'),$_smarty_tpl);?>
">
        <img src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['image']->value, ENT_QUOTES, 'UTF-8', true);?>
" alt="<?php echo smartyTranslate(array('s'=>'Pague com PagSeguro e parcele em até 18 vezes','mod'=>'pagseguro'),$_smarty_tpl);?>
" />
            <?php echo smartyTranslate(array('s'=>'Pague com PagSeguro e parcele em até 18 vezes','mod'=>'pagseguro'),$_smarty_tpl);?>

    </a>
</p> 
<?php }?>
<?php }} ?>
