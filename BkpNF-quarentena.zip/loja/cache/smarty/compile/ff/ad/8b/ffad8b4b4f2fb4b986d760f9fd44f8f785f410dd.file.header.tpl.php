<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:15
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:199367043256e8a2ffbd11f4-20535208%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ffad8b4b4f2fb4b986d760f9fd44f8f785f410dd' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/header.tpl',
      1 => 1455299873,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '199367043256e8a2ffbd11f4-20535208',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'lang_iso' => 0,
    'meta_title' => 0,
    'meta_description' => 0,
    'meta_keywords' => 0,
    'nobots' => 0,
    'nofollow' => 0,
    'favicon_url' => 0,
    'img_update_time' => 0,
    'css_files' => 0,
    'css_uri' => 0,
    'media' => 0,
    'css_dir' => 0,
    'PTS_SKIN_DEFAULT' => 0,
    'content_dir' => 0,
    'PTS_THEMENAME' => 0,
    'PTS_LANG_RTL' => 0,
    'js_defer' => 0,
    'js_files' => 0,
    'js_def' => 0,
    'js_uri' => 0,
    'HOOK_HEADER' => 0,
    'page_name' => 0,
    'body_classes' => 0,
    'hide_left_column' => 0,
    'hide_right_column' => 0,
    'content_only' => 0,
    'PTS_PANELTOOL' => 0,
    'PTS_PANELTOOL_TPL' => 0,
    'PTS_MODE' => 0,
    'restricted_country_mode' => 0,
    'geolocation_country' => 0,
    'base_dir' => 0,
    'shop_name' => 0,
    'logo_url' => 0,
    'logo_image_width' => 0,
    'logo_image_height' => 0,
    'HOOK_TOP' => 0,
    'HOOK_MEGAMENU' => 0,
    'HOOK_BLOCKPOSITION1' => 0,
    'HOOK_TABCATEGORYSLIDER' => 0,
    'HOOK_TESTIMONIALS' => 0,
    'HOOK_NEWPRODUCTSLIDER' => 0,
    'HOOK_BLOCKPOSITION2' => 0,
    'HOOK_FEATUREDPRODUCTSLIDER' => 0,
    'left_column_size' => 0,
    'HOOK_LEFT_COLUMN' => 0,
    'right_column_size' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a30000ff69_23070987',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a30000ff69_23070987')) {function content_56e8a30000ff69_23070987($_smarty_tpl) {?><?php if (!is_callable('smarty_function_implode')) include '/var/www/html/nfsolucoesdigitais.com.br/web/loja/tools/smarty/plugins/function.implode.php';
?>

<!DOCTYPE HTML>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7 " lang="<?php echo $_smarty_tpl->tpl_vars['lang_iso']->value;?>
"><![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8 ie7" lang="<?php echo $_smarty_tpl->tpl_vars['lang_iso']->value;?>
"><![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9 ie8" lang="<?php echo $_smarty_tpl->tpl_vars['lang_iso']->value;?>
"><![endif]-->
<!--[if gt IE 8]> <html class="no-js ie9" lang="<?php echo $_smarty_tpl->tpl_vars['lang_iso']->value;?>
"><![endif]-->
<html lang="<?php echo $_smarty_tpl->tpl_vars['lang_iso']->value;?>
" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta charset="utf-8" />
        <title><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['meta_title']->value, ENT_QUOTES, 'UTF-8', true);?>
</title>
        <?php if (isset($_smarty_tpl->tpl_vars['meta_description']->value)&&$_smarty_tpl->tpl_vars['meta_description']->value) {?>
            <meta name="description" content="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['meta_description']->value, ENT_QUOTES, 'UTF-8', true);?>
" />
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['meta_keywords']->value)&&$_smarty_tpl->tpl_vars['meta_keywords']->value) {?>
            <meta name="keywords" content="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['meta_keywords']->value, ENT_QUOTES, 'UTF-8', true);?>
" />
        <?php }?>
        <meta name="generator" content="PrestaShop" />
        <meta name="robots" content="<?php if (isset($_smarty_tpl->tpl_vars['nobots']->value)) {?>no<?php }?>index,<?php if (isset($_smarty_tpl->tpl_vars['nofollow']->value)&&$_smarty_tpl->tpl_vars['nofollow']->value) {?>no<?php }?>follow" />
        <meta name="viewport" content="width=device-width, minimum-scale=0.25, maximum-scale=1.6, initial-scale=1.0" /> 
        <meta name="apple-mobile-web-app-capable" content="yes" /> 
        <link rel="icon" type="image/vnd.microsoft.icon" href="<?php echo $_smarty_tpl->tpl_vars['favicon_url']->value;?>
?<?php echo $_smarty_tpl->tpl_vars['img_update_time']->value;?>
" />
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo $_smarty_tpl->tpl_vars['favicon_url']->value;?>
?<?php echo $_smarty_tpl->tpl_vars['img_update_time']->value;?>
" />
        <?php if (isset($_smarty_tpl->tpl_vars['css_files']->value)) {?>
            
            
            <?php  $_smarty_tpl->tpl_vars['media'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['media']->_loop = false;
 $_smarty_tpl->tpl_vars['css_uri'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['css_files']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['media']->key => $_smarty_tpl->tpl_vars['media']->value) {
$_smarty_tpl->tpl_vars['media']->_loop = true;
 $_smarty_tpl->tpl_vars['css_uri']->value = $_smarty_tpl->tpl_vars['media']->key;
?>
                <?php if (!strstr($_smarty_tpl->tpl_vars['css_uri']->value,"global.css")&&(!strstr($_smarty_tpl->tpl_vars['css_uri']->value,"rtl.css")||strstr($_smarty_tpl->tpl_vars['css_uri']->value,"_rtl.css"))&&!strstr($_smarty_tpl->tpl_vars['css_uri']->value,"jquery.bxslider.css")) {?>
                    <link rel="stylesheet" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['css_uri']->value, ENT_QUOTES, 'UTF-8', true);?>
" type="text/css" media="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['media']->value, ENT_QUOTES, 'UTF-8', true);?>
" />
                <?php }?>
            <?php } ?>
            
            <link href="<?php echo $_smarty_tpl->tpl_vars['css_dir']->value;?>
styles_css3.css" rel="stylesheet" type="text/css" media="all" />
            
        <?php }?>
        <?php if ($_smarty_tpl->tpl_vars['PTS_SKIN_DEFAULT']->value!="brown_red") {?>
            <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['content_dir']->value;?>
themes/<?php echo $_smarty_tpl->tpl_vars['PTS_THEMENAME']->value;?>
/css/global_brown_red.css"/>
        <?php }?>
        <?php if ($_smarty_tpl->tpl_vars['PTS_SKIN_DEFAULT']->value&&$_smarty_tpl->tpl_vars['PTS_SKIN_DEFAULT']->value!="default") {?>
            <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['content_dir']->value;?>
themes/<?php echo $_smarty_tpl->tpl_vars['PTS_THEMENAME']->value;?>
/css/global_<?php echo $_smarty_tpl->tpl_vars['PTS_SKIN_DEFAULT']->value;?>
.css"/>
        <?php } else { ?>
            <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['content_dir']->value;?>
themes/<?php echo $_smarty_tpl->tpl_vars['PTS_THEMENAME']->value;?>
/css/global_teal.css"/>
        <?php }?>
        <?php if ($_smarty_tpl->tpl_vars['PTS_LANG_RTL']->value==1) {?>
            <link rel="stylesheet" type="text/css" href="<?php echo $_smarty_tpl->tpl_vars['content_dir']->value;?>
themes/<?php echo $_smarty_tpl->tpl_vars['PTS_THEMENAME']->value;?>
/css/rtl.css"/>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['js_defer']->value)&&!$_smarty_tpl->tpl_vars['js_defer']->value&&isset($_smarty_tpl->tpl_vars['js_files']->value)&&isset($_smarty_tpl->tpl_vars['js_def']->value)) {?>
            <?php echo $_smarty_tpl->tpl_vars['js_def']->value;?>

            <?php  $_smarty_tpl->tpl_vars['js_uri'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['js_uri']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['js_files']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['js_uri']->key => $_smarty_tpl->tpl_vars['js_uri']->value) {
$_smarty_tpl->tpl_vars['js_uri']->_loop = true;
?>
                <script type="text/javascript" src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['js_uri']->value, ENT_QUOTES, 'UTF-8', true);?>
"></script>
            <?php } ?>
            
            
        <?php }?>
        <?php echo $_smarty_tpl->tpl_vars['HOOK_HEADER']->value;?>


        <!--[if IE 8]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
    <body<?php if (isset($_smarty_tpl->tpl_vars['page_name']->value)) {?> id="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['page_name']->value, ENT_QUOTES, 'UTF-8', true);?>
"<?php }?> class="<?php if (isset($_smarty_tpl->tpl_vars['page_name']->value)) {?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['page_name']->value, ENT_QUOTES, 'UTF-8', true);?>
<?php }?><?php if (isset($_smarty_tpl->tpl_vars['body_classes']->value)&&count($_smarty_tpl->tpl_vars['body_classes']->value)) {?> <?php echo smarty_function_implode(array('value'=>$_smarty_tpl->tpl_vars['body_classes']->value,'separator'=>' '),$_smarty_tpl);?>
<?php }?><?php if ($_smarty_tpl->tpl_vars['hide_left_column']->value) {?> hide-left-column<?php }?><?php if ($_smarty_tpl->tpl_vars['hide_right_column']->value) {?> hide-right-column<?php }?><?php if (isset($_smarty_tpl->tpl_vars['content_only']->value)&&$_smarty_tpl->tpl_vars['content_only']->value) {?> content_only<?php }?> lang_<?php echo $_smarty_tpl->tpl_vars['lang_iso']->value;?>
">
        <?php if ($_smarty_tpl->tpl_vars['PTS_PANELTOOL']->value) {?>
                <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['PTS_PANELTOOL_TPL']->value), $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php } else { ?>
                <?php if ($_smarty_tpl->tpl_vars['PTS_MODE']->value==1) {?>
                    <script type="text/javascript">
//<![CDATA[
                        $('#page').css('width','');
                        $('body').append('<style id="setconfig">#page{ background-color: #f1f1f1; width: 1200px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2); margin: 0 auto;} @media only screen and (min-width: 992px) and (max-width: 1200px) {	#page{	width: 980px;}}@media only screen and (max-width: 991px){ #page{ margin:0 auto;border-radius:0;box-shadow: 0 0 0 #fff;}}@media only screen and (min-width: 768px) and (max-width: 991px) {	#page { width: 768px;}}@media only screen and (max-width: 767px){ #page { width:100%;}}</style>');
//]]>
</script>
                <?php }?>
            <?php }?>
        <?php if (!isset($_smarty_tpl->tpl_vars['content_only']->value)||!$_smarty_tpl->tpl_vars['content_only']->value) {?>
            <?php if (isset($_smarty_tpl->tpl_vars['restricted_country_mode']->value)&&$_smarty_tpl->tpl_vars['restricted_country_mode']->value) {?>
                <div id="restricted-country">
                    <p><?php echo smartyTranslate(array('s'=>'You cannot place a new order from your country.'),$_smarty_tpl);?>
 <span class="bold"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['geolocation_country']->value, ENT_QUOTES, 'UTF-8', true);?>
</span></p>
                </div>
            <?php }?>
            <div id="page">
                <div class="header-container">
                    <header id="header">
                        <div class="banner">
                            <div class="container">
                                <div class="row">
                                    <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>"container"),$_smarty_tpl);?>

                                </div>
                            </div>
                        </div>
                        <div class="nav">
                            <div class="container">
                                <div class="row">
                                    <nav><div class="lc"><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>"displayNav"),$_smarty_tpl);?>
</nav>
                                </div>
                            </div>
                        </div>
                        <div class="wrap_header_logo">
                            <div class="container">
                                <div class="row">
                                    <div id="header_logo" class="col-xs-4 col-sm-4 col-md-4">
                                        <a href="<?php echo $_smarty_tpl->tpl_vars['base_dir']->value;?>
" title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['shop_name']->value, ENT_QUOTES, 'UTF-8', true);?>
">
                                            <img class="logo img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['logo_url']->value;?>
" alt="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['shop_name']->value, ENT_QUOTES, 'UTF-8', true);?>
"<?php if (isset($_smarty_tpl->tpl_vars['logo_image_width']->value)&&$_smarty_tpl->tpl_vars['logo_image_width']->value) {?> width="<?php echo $_smarty_tpl->tpl_vars['logo_image_width']->value;?>
"<?php }?><?php if (isset($_smarty_tpl->tpl_vars['logo_image_height']->value)&&$_smarty_tpl->tpl_vars['logo_image_height']->value) {?> height="<?php echo $_smarty_tpl->tpl_vars['logo_image_height']->value;?>
"<?php }?>/>
                                        </a>
                                    </div>
                                <div class="header-content col-xs-8 col-sm-8 col-md-8">
                                <?php if (isset($_smarty_tpl->tpl_vars['HOOK_TOP']->value)) {?><?php echo $_smarty_tpl->tpl_vars['HOOK_TOP']->value;?>
<?php }?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="top-menu">
                    <div class="shadow-top-menu"></div>
                    <div class="container">
                        <div class="row">
                           
                            <?php echo $_smarty_tpl->tpl_vars['HOOK_MEGAMENU']->value;?>

                        </div> 
                    </div> 
                </div> 
                <?php if ($_smarty_tpl->tpl_vars['page_name']->value=='index') {?>
                    <div class="slider"> 
                        <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>"displayBanner"),$_smarty_tpl);?>

                    </div>
                <?php }?>
            </header>
        </div>
            <?php if ($_smarty_tpl->tpl_vars['page_name']->value=='index') {?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOOK_BLOCKPOSITION1']->value)&&!empty($_smarty_tpl->tpl_vars['HOOK_BLOCKPOSITION1']->value)) {?>
     <?php echo $_smarty_tpl->tpl_vars['HOOK_BLOCKPOSITION1']->value;?>

    <?php }?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOOK_TABCATEGORYSLIDER']->value)&&!empty($_smarty_tpl->tpl_vars['HOOK_TABCATEGORYSLIDER']->value)) {?>
     <?php echo $_smarty_tpl->tpl_vars['HOOK_TABCATEGORYSLIDER']->value;?>

    <?php }?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOOK_TESTIMONIALS']->value)&&!empty($_smarty_tpl->tpl_vars['HOOK_TESTIMONIALS']->value)) {?>
     <?php echo $_smarty_tpl->tpl_vars['HOOK_TESTIMONIALS']->value;?>

    <?php }?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOOK_NEWPRODUCTSLIDER']->value)&&!empty($_smarty_tpl->tpl_vars['HOOK_NEWPRODUCTSLIDER']->value)) {?>
     <?php echo $_smarty_tpl->tpl_vars['HOOK_NEWPRODUCTSLIDER']->value;?>

    <?php }?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOOK_BLOCKPOSITION2']->value)&&!empty($_smarty_tpl->tpl_vars['HOOK_BLOCKPOSITION2']->value)) {?>
     <?php echo $_smarty_tpl->tpl_vars['HOOK_BLOCKPOSITION2']->value;?>

    <?php }?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOOK_FEATUREDPRODUCTSLIDER']->value)&&!empty($_smarty_tpl->tpl_vars['HOOK_FEATUREDPRODUCTSLIDER']->value)) {?>
     <?php echo $_smarty_tpl->tpl_vars['HOOK_FEATUREDPRODUCTSLIDER']->value;?>

    <?php }?>
   <?php }?>
        <div class="columns-container">
            <div id="columns" class="container">
                <div class="row">
                    <?php if (isset($_smarty_tpl->tpl_vars['left_column_size']->value)&&!empty($_smarty_tpl->tpl_vars['left_column_size']->value)) {?>
                        <div id="left_column" class="column col-xs-12 col-sm-<?php echo intval($_smarty_tpl->tpl_vars['left_column_size']->value);?>
">
                            <?php echo $_smarty_tpl->tpl_vars['HOOK_LEFT_COLUMN']->value;?>

                        </div>
                    <?php }?>
                    <?php if ($_smarty_tpl->tpl_vars['page_name']->value=='module-ph_simpleblog-list'||$_smarty_tpl->tpl_vars['page_name']->value=='module-ph_simpleblog-single') {?><?php $_smarty_tpl->tpl_vars['right_column_size'] = new Smarty_variable(0, null, 0);?><?php }?>
                    <div id="center_column" class="center_column col-xs-12 col-sm-<?php echo 12-$_smarty_tpl->tpl_vars['left_column_size']->value-$_smarty_tpl->tpl_vars['right_column_size']->value;?>
">
                        <?php if ($_smarty_tpl->tpl_vars['page_name']->value!='index'&&$_smarty_tpl->tpl_vars['page_name']->value!='pagenotfound') {?>
                            <?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['tpl_dir']->value)."./breadcrumb.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                        <?php }?>
                    <?php }?><?php }} ?>
