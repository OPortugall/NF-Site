<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:31:20
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/controllers/login/layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:150781108656e8a958a80d35-54242922%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3ac9075b5a1f80d26c8423fcd77210c04d9fa0d9' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/controllers/login/layout.tpl',
      1 => 1455401129,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '150781108656e8a958a80d35-54242922',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'page' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a958a8cfd1_55370010',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a958a8cfd1_55370010')) {function content_56e8a958a8cfd1_55370010($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
