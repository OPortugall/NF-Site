<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:16
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:56492793956e8a300308394-58835763%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '82df9290c799081800a2a41bfb1d1b1702d1631e' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/footer.tpl',
      1 => 1455299873,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '56492793956e8a300308394-58835763',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content_only' => 0,
    'right_column_size' => 0,
    'page_name' => 0,
    'HOOK_RIGHT_COLUMN' => 0,
    'HOOK_BLOCKPOSITION3' => 0,
    'HOOK_PRODUCT_FOOTER' => 0,
    'HOOK_BRAND' => 0,
    'HOOK_BLOCKFOOTER3' => 0,
    'HOOK_BLOCKFOOTER4' => 0,
    'HOOK_BLOCKFOOTER1' => 0,
    'HOOK_BLOCKFOOTER2' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a3003a85a5_42118050',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a3003a85a5_42118050')) {function content_56e8a3003a85a5_42118050($_smarty_tpl) {?>
<?php if (!isset($_smarty_tpl->tpl_vars['content_only']->value)||!$_smarty_tpl->tpl_vars['content_only']->value) {?>
					</div><!-- #center_column -->
					<?php if (isset($_smarty_tpl->tpl_vars['right_column_size']->value)&&!empty($_smarty_tpl->tpl_vars['right_column_size']->value)&&$_smarty_tpl->tpl_vars['page_name']->value!='module-ph_simpleblog-list'&&$_smarty_tpl->tpl_vars['page_name']->value!='module-ph_simpleblog-single') {?>
						<div id="right_column" class="col-xs-12 col-sm-<?php echo intval($_smarty_tpl->tpl_vars['right_column_size']->value);?>
 column"><?php echo $_smarty_tpl->tpl_vars['HOOK_RIGHT_COLUMN']->value;?>
</div>
					<?php }?>
					</div><!-- .row -->
				</div><!-- #columns -->
			</div><!-- .columns-container -->
                        <?php echo $_smarty_tpl->tpl_vars['HOOK_BLOCKPOSITION3']->value;?>

                        <?php if ($_smarty_tpl->tpl_vars['page_name']->value=='index') {?>
                                <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>"displaySimpleBlogRecentPosts"),$_smarty_tpl);?>

                        <?php }?>
                        <?php if (isset($_smarty_tpl->tpl_vars['HOOK_PRODUCT_FOOTER']->value)&&!empty($_smarty_tpl->tpl_vars['HOOK_PRODUCT_FOOTER']->value)) {?>
                            <div class ="container">
				<?php echo $_smarty_tpl->tpl_vars['HOOK_PRODUCT_FOOTER']->value;?>

                            </div>  
                        <?php }?>
                        <div class="container">
                                <div class="row">
                                     <?php echo $_smarty_tpl->tpl_vars['HOOK_BRAND']->value;?>

                                </div>
			</div>
			<div id="footer" class="footer-container">
				<div class="footer-center">
					<div class="container">
                                            <div class="row">
                                                    <div class="left_footer col-sm-4 col-md-3 col-sms-6 col-smb-12">
                                                       <?php echo $_smarty_tpl->tpl_vars['HOOK_BLOCKFOOTER3']->value;?>

                                                    </div>
                                                    <div class="right_footer">
                                                        <?php echo $_smarty_tpl->tpl_vars['HOOK_BLOCKFOOTER4']->value;?>

                                                        <?php echo $_smarty_tpl->tpl_vars['HOOK_BLOCKFOOTER1']->value;?>

                                                    </div>
                                                </div>
					</div>
				</div>
				<div class="footer-bottom">
					<div class="container">
                                            <div class="row">
						    <?php echo $_smarty_tpl->tpl_vars['HOOK_BLOCKFOOTER2']->value;?>

                                            </div>
					</div>
				</div>
                                
			</div><!-- #footer -->
		</div><!-- #page -->
<?php }?>
<div class="back-top"><a href= "#" class="mypresta_scrollup hidden-phone"><i class="icon-chevron-up"></i></a></div>
<?php echo $_smarty_tpl->getSubTemplate (((string)$_smarty_tpl->tpl_vars['tpl_dir']->value)."./global.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

	</body>
</html><?php }} ?>
