<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:14
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockuserinfo/blockuserinfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:151363109056e8a2fef19c25-85837078%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a59299f65b13e2ed4cb29c84c7971bc21727898' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockuserinfo/blockuserinfo.tpl',
      1 => 1455299876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '151363109056e8a2fef19c25-85837078',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fef1c609_32427466',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fef1c609_32427466')) {function content_56e8a2fef1c609_32427466($_smarty_tpl) {?><?php }} ?>
