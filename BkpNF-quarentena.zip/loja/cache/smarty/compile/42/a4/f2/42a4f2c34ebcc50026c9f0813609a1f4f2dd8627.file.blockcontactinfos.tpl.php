<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:15
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcontactinfos/blockcontactinfos.tpl" */ ?>
<?php /*%%SmartyHeaderCode:95086473956e8a2ff75e218-88163258%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '42a4f2c34ebcc50026c9f0813609a1f4f2dd8627' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockcontactinfos/blockcontactinfos.tpl',
      1 => 1455299875,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '95086473956e8a2ff75e218-88163258',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'blockcontactinfos_company' => 0,
    'blockcontactinfos_address' => 0,
    'blockcontactinfos_phone' => 0,
    'blockcontactinfos_email' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2ff7bb864_50748278',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2ff7bb864_50748278')) {function content_56e8a2ff7bb864_50748278($_smarty_tpl) {?><?php if (!is_callable('smarty_function_mailto')) include '/var/www/html/nfsolucoesdigitais.com.br/web/loja/tools/smarty/plugins/function.mailto.php';
?>

<!-- MODULE Block contact infos -->
<section id="block_contact_infos">
	<div>
        <h4><?php echo smartyTranslate(array('s'=>'ABOUT US','mod'=>'blockcontactinfos'),$_smarty_tpl);?>
</h4>
        <div class="ft_map">
            <p><?php echo smartyTranslate(array('s'=>'A NF Soluções Digitais possui perfis nas principais redes sociais utilizadas por brasileiros.','mod'=>'blockcontactinfos'),$_smarty_tpl);?>
</p>
            <ul class="toggle-footer">
                <?php if ($_smarty_tpl->tpl_vars['blockcontactinfos_company']->value!='') {?>
                    <li>
                        <span class="ci_icon"><i class="icon-map-marker"></i></span>
                    <?php if ($_smarty_tpl->tpl_vars['blockcontactinfos_address']->value!='') {?><span class="ci_content"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['blockcontactinfos_address']->value, ENT_QUOTES, 'UTF-8', true);?>
</span><?php }?>
                    </li>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['blockcontactinfos_phone']->value!='') {?>
                    <li>
                            <span class="ci_icon"><i class="icon-phone"></i></span>
                            <span class="ci_content"><?php echo smartyTranslate(array('s'=>'Call us now:','mod'=>'blockcontactinfos'),$_smarty_tpl);?>
 <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['blockcontactinfos_phone']->value, ENT_QUOTES, 'UTF-8', true);?>
</span>
                    </li>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['blockcontactinfos_email']->value!='') {?>
                    <li>
                            <span class="ci_icon"><i class="icon-envelope-alt"></i></span> 
                            <span class="ci_content"><?php echo smartyTranslate(array('s'=>'Email:','mod'=>'blockcontactinfos'),$_smarty_tpl);?>
 <?php echo smarty_function_mailto(array('address'=>htmlspecialchars($_smarty_tpl->tpl_vars['blockcontactinfos_email']->value, ENT_QUOTES, 'UTF-8', true),'encode'=>"hex"),$_smarty_tpl);?>
</span>
                    </li>
                <?php }?>
            </ul>
        </div>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
