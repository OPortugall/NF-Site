<?php /* Smarty version Smarty-3.1.19, created on 2016-04-05 18:27:09
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/controllers/emails/content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:54859435957041f9d8a6011-93065690%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fdaa68b95ddf25c565bd9aab3bddb18fa41aa7f0' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/admin536fjwnxs/themes/default/template/controllers/emails/content.tpl',
      1 => 1455401129,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '54859435957041f9d8a6011-93065690',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57041f9d93fa69_67892431',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57041f9d93fa69_67892431')) {function content_57041f9d93fa69_67892431($_smarty_tpl) {?>

<?php if (isset($_smarty_tpl->tpl_vars['content']->value)) {?>
	<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

<?php }?><?php }} ?>
