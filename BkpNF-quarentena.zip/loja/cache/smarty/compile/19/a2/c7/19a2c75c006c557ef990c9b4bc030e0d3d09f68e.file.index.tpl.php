<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:15
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:103578812756e8a2ffa82759-53994885%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '19a2c75c006c557ef990c9b4bc030e0d3d09f68e' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/index.tpl',
      1 => 1455299873,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '103578812756e8a2ffa82759-53994885',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'HOOK_HOME_TAB_CONTENT' => 0,
    'HOOK_HOME_TAB' => 0,
    'HOOK_HOME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2ffadb539_53809701',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2ffadb539_53809701')) {function content_56e8a2ffadb539_53809701($_smarty_tpl) {?>
<?php if (isset($_smarty_tpl->tpl_vars['HOOK_HOME_TAB_CONTENT']->value)&&trim($_smarty_tpl->tpl_vars['HOOK_HOME_TAB_CONTENT']->value)) {?>
    <?php if (isset($_smarty_tpl->tpl_vars['HOOK_HOME_TAB']->value)&&trim($_smarty_tpl->tpl_vars['HOOK_HOME_TAB']->value)) {?>
        <ul id="home-page-tabs" class="nav nav-tabs clearfix">
			<?php echo $_smarty_tpl->tpl_vars['HOOK_HOME_TAB']->value;?>

		</ul>
	<?php }?>
	<div class="tab-content"><?php echo $_smarty_tpl->tpl_vars['HOOK_HOME_TAB_CONTENT']->value;?>
</div>
<?php }?>
<?php if (isset($_smarty_tpl->tpl_vars['HOOK_HOME']->value)&&trim($_smarty_tpl->tpl_vars['HOOK_HOME']->value)) {?>
	<div class="clearfix">
            <?php echo $_smarty_tpl->tpl_vars['HOOK_HOME']->value;?>

        </div>
<?php }?><?php }} ?>
