<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:14
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsstaticblocks/block.tpl" */ ?>
<?php /*%%SmartyHeaderCode:74126804956e8a2fe3bc239-14996651%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3ccf1acdd0ae8f60942e0f14fd4fd0973a1dbb54' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsstaticblocks/block.tpl',
      1 => 1455299865,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '74126804956e8a2fe3bc239-14996651',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'staticblocks' => 0,
    'block' => 0,
    'page_name' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fe43d509_80358185',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fe43d509_80358185')) {function content_56e8a2fe43d509_80358185($_smarty_tpl) {?>
<?php  $_smarty_tpl->tpl_vars['block'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['block']->_loop = false;
 $_smarty_tpl->tpl_vars['key'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['staticblocks']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['block']->key => $_smarty_tpl->tpl_vars['block']->value) {
$_smarty_tpl->tpl_vars['block']->_loop = true;
 $_smarty_tpl->tpl_vars['key']->value = $_smarty_tpl->tpl_vars['block']->key;
?>
    <?php if ($_smarty_tpl->tpl_vars['block']->value['identify']=='top-info'||$_smarty_tpl->tpl_vars['block']->value['identify']=='Static-block-right') {?>
                <?php if ($_smarty_tpl->tpl_vars['block']->value['active']==1) {?>
                        <p class ="title_block"> <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['block']->value['title'];?>
<?php $_tmp3=ob_get_clean();?><?php echo smartyTranslate(array('s'=>$_tmp3),$_smarty_tpl);?>
 </p>
                <?php }?>
                <?php echo $_smarty_tpl->tpl_vars['block']->value['description'];?>

                <?php if ($_smarty_tpl->tpl_vars['block']->value['insert_module']==1) {?>
                      <?php echo $_smarty_tpl->tpl_vars['block']->value['block_module'];?>

                 <?php }?>
    <?php } else { ?>
           <?php if ($_smarty_tpl->tpl_vars['page_name']->value=='index') {?>
               <?php if ($_smarty_tpl->tpl_vars['block']->value['active']==1) {?>
                        <p class ="title_block"> <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['block']->value['title'];?>
<?php $_tmp4=ob_get_clean();?><?php echo smartyTranslate(array('s'=>$_tmp4),$_smarty_tpl);?>
 </p>
                <?php }?>
                <?php echo $_smarty_tpl->tpl_vars['block']->value['description'];?>

                <?php if ($_smarty_tpl->tpl_vars['block']->value['insert_module']==1) {?>
                      <?php echo $_smarty_tpl->tpl_vars['block']->value['block_module'];?>

                 <?php }?>
            <?php }?>
    <?php }?>
<?php } ?>
 <?php }} ?>
