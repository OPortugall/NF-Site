<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:14
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsbrand/brand.tpl" */ ?>
<?php /*%%SmartyHeaderCode:203823507256e8a2fe489d41-20387330%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3b25757d6065b85a883fd4238bae309ea983d9ed' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/modules/ptsbrand/brand.tpl',
      1 => 1455383014,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203823507256e8a2fe489d41-20387330',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'brands' => 0,
    'brand' => 0,
    'slideOptions' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fe4fd551_81752572',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fe4fd551_81752572')) {function content_56e8a2fe4fd551_81752572($_smarty_tpl) {?><div class="pts-brand-container">	
    <div class="container">	
        <div class="container-inner">
            <div class="pts-brand">
                <div class="pts-brand-title title_block"><h4><?php echo smartyTranslate(array('s'=>'Brands','mod'=>'ptsbrand'),$_smarty_tpl);?>
</h4></div>
                <ul class="bxslider">
                    <?php  $_smarty_tpl->tpl_vars['brand'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['brand']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['brands']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['brand']->key => $_smarty_tpl->tpl_vars['brand']->value) {
$_smarty_tpl->tpl_vars['brand']->_loop = true;
?>
                        <li>
                            <a href ="<?php echo $_smarty_tpl->tpl_vars['brand']->value['link'];?>
">
                                <img src ="<?php echo $_smarty_tpl->tpl_vars['brand']->value['image'];?>
" alt ="<?php echo smartyTranslate(array('s'=>'Brand','mod'=>'ptsbrand'),$_smarty_tpl);?>
" />
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>
    <script type="text/javascript">
              $('.pts-brand .bxslider').bxSlider({
        auto: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['auto']!=1) {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['auto'];?>
<?php } else { ?>1<?php }?>,
        slideWidth:<?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['width_item']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['width_item'];?>
<?php } else { ?>250<?php }?>,
                    slideMargin: 5,
                    minSlides: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['min_item']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['min_item'];?>
<?php } else { ?>3<?php }?>,
                    maxSlides: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['max_item']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['max_item'];?>
<?php } else { ?>8<?php }?>,
                    speed:  <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['speed_slide']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['speed_slide'];?>
<?php } else { ?>5000<?php }?>,
                    pause: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['a_speed']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['a_speed'];?>
<?php } else { ?>1000<?php }?>,
                    controls: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['show_nexback']!=0) {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['show_nexback'];?>
<?php } else { ?>false<?php }?>,
        pager: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['show_control']!=0) {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['show_control'];?>
<?php } else { ?>false<?php }?>,
            });
    </script>
</div><?php }} ?>
