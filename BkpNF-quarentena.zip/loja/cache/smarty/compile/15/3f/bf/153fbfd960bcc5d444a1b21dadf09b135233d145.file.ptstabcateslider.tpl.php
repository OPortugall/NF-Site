<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:13
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/ptstabcateslider/ptstabcateslider.tpl" */ ?>
<?php /*%%SmartyHeaderCode:127825846756e8a2fdd61063-05683726%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '153fbfd960bcc5d444a1b21dadf09b135233d145' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/ptstabcateslider/ptstabcateslider.tpl',
      1 => 1455299878,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '127825846756e8a2fdd61063-05683726',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tab_effect' => 0,
    'title' => 0,
    'productCates' => 0,
    'productCate' => 0,
    'count' => 0,
    'product' => 0,
    'link' => 0,
    'largeSize' => 0,
    'PS_CATALOG_MODE' => 0,
    'quick_view' => 0,
    'comparator_max_item' => 0,
    'add_prod_display' => 0,
    'restricted_country_mode' => 0,
    'static_token' => 0,
    'slideOptions' => 0,
    'priceDisplay' => 0,
    'compared_products' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fe1b2202_94402057',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fe1b2202_94402057')) {function content_56e8a2fe1b2202_94402057($_smarty_tpl) {?><script type="text/javascript">

    $(document).ready(function() {

        $(".tab_category_slider").hide();
        $(".tab_category_slider:first").show();

        $("ul.tab_cates li").click(function() {
            $("ul.tab_cates li").removeClass("active");
            $(this).addClass("active");
            $(".tab_category_slider").hide();
            $(".tab_category_slider").removeClass("animate1 <?php echo $_smarty_tpl->tpl_vars['tab_effect']->value;?>
");
            var activeTab = $(this).attr("rel");
            $("#" + activeTab).addClass("animate1 <?php echo $_smarty_tpl->tpl_vars['tab_effect']->value;?>
");
            $("#" + activeTab).fadeIn();
        });
    });

</script>

<div class="tab-category-container-slider">
    <div class="container">
            <div class="row">
    <div class="tab-category-slider">
        <?php if ($_smarty_tpl->tpl_vars['title']->value) {?>
            <div class ='cate_title'>
                <h2><?php echo smartyTranslate(array('s'=>'WEEKLY FEATURED','mod'=>'ptstabcateslider'),$_smarty_tpl);?>
</h2>
            </div>
        <?php }?>
        <ul class="tab_cates"> 
            <?php $_smarty_tpl->tpl_vars['count'] = new Smarty_variable(0, null, 0);?>
            <?php  $_smarty_tpl->tpl_vars['productCate'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['productCate']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['productCates']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['productCate']->key => $_smarty_tpl->tpl_vars['productCate']->value) {
$_smarty_tpl->tpl_vars['productCate']->_loop = true;
?>
                <li rel="tab_<?php echo $_smarty_tpl->tpl_vars['productCate']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['count']->value==0) {?> class="active"  <?php }?> > <?php echo $_smarty_tpl->tpl_vars['productCate']->value['name'];?>
</li>
                    <?php $_smarty_tpl->tpl_vars['count'] = new Smarty_variable($_smarty_tpl->tpl_vars['count']->value+1, null, 0);?>
                <?php } ?>	
        </ul>

        <div class="tab_cate_container"> 
            <?php  $_smarty_tpl->tpl_vars['productCate'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['productCate']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['productCates']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['productCate']->key => $_smarty_tpl->tpl_vars['productCate']->value) {
$_smarty_tpl->tpl_vars['productCate']->_loop = true;
?>

                <div id="tab_<?php echo $_smarty_tpl->tpl_vars['productCate']->value['id'];?>
" class="tab_category_slider"> 
                    <ul class="productTabCategorySlider">
                        <?php  $_smarty_tpl->tpl_vars['product'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['product']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['productCate']->value['product']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['product']->key => $_smarty_tpl->tpl_vars['product']->value) {
$_smarty_tpl->tpl_vars['product']->_loop = true;
?>
                            <li class="cate_item ajax_block_product">
                                <div class="item-inner">
                                    <div class="left-block">	
                                        <a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
" class="product_image">
                                            <?php if ($_smarty_tpl->tpl_vars['link']->value->getImageLink($_smarty_tpl->tpl_vars['product']->value['link_rewrite'],$_smarty_tpl->tpl_vars['product']->value['id_image'],'large_default',$_smarty_tpl->tpl_vars['product']->value['id_product'])!="0") {?>
                                                <span class="hover-image"><img class="replace-2x img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['link']->value->getImageLink($_smarty_tpl->tpl_vars['product']->value['link_rewrite'],$_smarty_tpl->tpl_vars['product']->value['id_image'],'large_default',$_smarty_tpl->tpl_vars['product']->value['id_product']);?>
" alt="<?php if (!empty($_smarty_tpl->tpl_vars['product']->value['legend'])) {?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['legend'], ENT_QUOTES, 'UTF-8', true);?>
<?php } else { ?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
<?php }?>" title="<?php if (!empty($_smarty_tpl->tpl_vars['product']->value['legend'])) {?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['legend'], ENT_QUOTES, 'UTF-8', true);?>
<?php } else { ?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
<?php }?>" <?php if (isset($_smarty_tpl->tpl_vars['largeSize']->value)) {?> width="<?php echo $_smarty_tpl->tpl_vars['largeSize']->value['width'];?>
" height="<?php echo $_smarty_tpl->tpl_vars['largeSize']->value['height'];?>
"<?php }?>/></span>
                                            <?php }?>
                                            <img src="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getImageLink($_smarty_tpl->tpl_vars['product']->value['link_rewrite'],$_smarty_tpl->tpl_vars['product']->value['id_image'],'large_default'), ENT_QUOTES, 'UTF-8', true);?>
" <?php if (isset($_smarty_tpl->tpl_vars['largeSize']->value)) {?> width="<?php echo $_smarty_tpl->tpl_vars['largeSize']->value['width'];?>
" height="<?php echo $_smarty_tpl->tpl_vars['largeSize']->value['height'];?>
"<?php }?> alt="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['name'], ENT_QUOTES, 'UTF-8', true);?>
" />
                                        </a>
                                        
					<?php if (isset($_smarty_tpl->tpl_vars['product']->value['on_sale'])&&$_smarty_tpl->tpl_vars['product']->value['on_sale']&&isset($_smarty_tpl->tpl_vars['product']->value['show_price'])&&$_smarty_tpl->tpl_vars['product']->value['show_price']&&!$_smarty_tpl->tpl_vars['PS_CATALOG_MODE']->value) {?>
						<span class="sale"><?php echo smartyTranslate(array('s'=>'Sale!','mod'=>'ptstabcateslider'),$_smarty_tpl);?>
</span>
					<?php }?>
                                            <div class="button-container fly_3 clearfix">
                                                <?php if (isset($_smarty_tpl->tpl_vars['quick_view']->value)&&$_smarty_tpl->tpl_vars['quick_view']->value) {?>
							<a class="quick-view" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
" rel="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
">
                                                            <span class="wrap_bg">
                                                            <i class="icon-eye-open icon-0x icon-mar-lr2"></i>
                                                            <span class="wrap_text"><?php echo smartyTranslate(array('s'=>'Quick view','mod'=>'ptstabcateslider'),$_smarty_tpl);?>
</span>
                                                            </span>
							</a>
						<?php }?>
                                                
                                                <?php if (isset($_smarty_tpl->tpl_vars['comparator_max_item']->value)&&$_smarty_tpl->tpl_vars['comparator_max_item']->value) {?>
                                                        <a class="add_to_compare" href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
" data-id-product="<?php echo $_smarty_tpl->tpl_vars['product']->value['id_product'];?>
"><?php echo smartyTranslate(array('s'=>''),$_smarty_tpl);?>

                                                                    <span class="wrap_bg">
                                                                        <i class="icon-plus icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text"><?php echo smartyTranslate(array('s'=>'add to compare','mod'=>'ptstabcateslider'),$_smarty_tpl);?>
</span>
                                                                    </span>
                                                        </a>
						<?php }?>
                                                <a class="addToWishlist wishlistProd_<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
" href="#" rel="nofollow" onclick="WishlistCart('wishlist_block_list', 'add', '<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
', false, 1); return false;"><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>'displayProductListFunctionalButtons','product'=>$_smarty_tpl->tpl_vars['product']->value),$_smarty_tpl);?>
</a>
                                                <?php if (($_smarty_tpl->tpl_vars['product']->value['id_product_attribute']==0||(isset($_smarty_tpl->tpl_vars['add_prod_display']->value)&&($_smarty_tpl->tpl_vars['add_prod_display']->value==1)))&&$_smarty_tpl->tpl_vars['product']->value['available_for_order']&&!isset($_smarty_tpl->tpl_vars['restricted_country_mode']->value)&&$_smarty_tpl->tpl_vars['product']->value['minimal_quantity']<=1&&$_smarty_tpl->tpl_vars['product']->value['customizable']!=2&&!$_smarty_tpl->tpl_vars['PS_CATALOG_MODE']->value) {?>
							<?php if (($_smarty_tpl->tpl_vars['product']->value['allow_oosp']||$_smarty_tpl->tpl_vars['product']->value['quantity']>0)) {?>
								<?php if (isset($_smarty_tpl->tpl_vars['static_token']->value)) {?>
									<a class="exclusive ajax_add_to_cart_button " href="<?php ob_start();?><?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
<?php $_tmp2=ob_get_clean();?><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getPageLink('cart',false,null,"add=1&amp;id_product=".$_tmp2."&amp;token=".((string)$_smarty_tpl->tpl_vars['static_token']->value),false), ENT_QUOTES, 'UTF-8', true);?>
" rel="nofollow" title="<?php echo smartyTranslate(array('s'=>'Add to cart'),$_smarty_tpl);?>
" data-id-product="<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
">
                                                                            <span class="wrap_bg">
                                                                        <i class="icon-shopping-cart icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text"><?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'ptstabcateslider'),$_smarty_tpl);?>
</span>
                                                                    </span>
									</a>
								<?php } else { ?>
									<a class="exclusive ajax_add_to_cart_button " href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['link']->value->getPageLink('cart',false,null,'add=1&amp;id_product={$product.id_product|intval}',false), ENT_QUOTES, 'UTF-8', true);?>
" rel="nofollow" title="<?php echo smartyTranslate(array('s'=>'Add to cart'),$_smarty_tpl);?>
" data-id-product="<?php echo intval($_smarty_tpl->tpl_vars['product']->value['id_product']);?>
">
                                                                            <span class="wrap_bg">
                                                                        <i class="icon-shopping-cart icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text"><?php echo smartyTranslate(array('s'=>'Add to cart','mod'=>'ptstabcateslider'),$_smarty_tpl);?>
</span>
                                                                    </span>
									</a>
								<?php }?>						
							<?php } else { ?>
								<a href="#" class="exclusive ajax_add_to_cart_button ">
                                                                    <span class="wrap_bg">
                                                                        <i class="icon-shopping-cart icon-0x icon-mar-lr2"></i>
                                                                        <span class="wrap_text"><?php echo smartyTranslate(array('s'=>'Out of stock','mod'=>'ptstabcateslider'),$_smarty_tpl);?>
</span>
                                                                    </span>
								</a
							<?php }?>
						<?php }?>
                                                
                                               
                                            </div>
                                    </div>
                                    <div class="right-block">
					<h5 class="s_title_block"><a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['truncate'][0][0]->smarty_modifier_truncate($_smarty_tpl->tpl_vars['product']->value['name'],50,'...'), ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
"><?php echo mb_convert_encoding(htmlspecialchars($_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['truncate'][0][0]->smarty_modifier_truncate($_smarty_tpl->tpl_vars['product']->value['name'],35,'...'), ENT_QUOTES, 'UTF-8', true), "HTML-ENTITIES", 'UTF-8');?>
</a></h5>
                                        <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['show_des']==1) {?>
                                            <div class="product_desc"><a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['product']->value['link'], ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo smartyTranslate(array('s'=>'More','mod'=>'ptsfeatureproduct'),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_MODIFIER]['truncate'][0][0]->smarty_modifier_truncate(preg_replace('!<[^>]*?>!', ' ', $_smarty_tpl->tpl_vars['product']->value['description_short']),65,'...');?>
</a></div>
                                        <?php }?>                                       
                                        <div class="pr-rt">
                                                <?php if ((!$_smarty_tpl->tpl_vars['PS_CATALOG_MODE']->value&&((isset($_smarty_tpl->tpl_vars['product']->value['show_price'])&&$_smarty_tpl->tpl_vars['product']->value['show_price'])||(isset($_smarty_tpl->tpl_vars['product']->value['available_for_order'])&&$_smarty_tpl->tpl_vars['product']->value['available_for_order'])))) {?>
                                                    <div class="content_price">
                                                            <?php if (isset($_smarty_tpl->tpl_vars['product']->value['show_price'])&&$_smarty_tpl->tpl_vars['product']->value['show_price']&&!isset($_smarty_tpl->tpl_vars['restricted_country_mode']->value)) {?>
                                                                    <span class="price product-price">
                                                                            <?php if (!$_smarty_tpl->tpl_vars['priceDisplay']->value) {?><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['convertPrice'][0][0]->convertPrice(array('price'=>$_smarty_tpl->tpl_vars['product']->value['price']),$_smarty_tpl);?>
<?php } else { ?><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['convertPrice'][0][0]->convertPrice(array('price'=>$_smarty_tpl->tpl_vars['product']->value['price_tax_exc']),$_smarty_tpl);?>
<?php }?>
                                                                    </span>
                                                                    
                                                                    <?php if (isset($_smarty_tpl->tpl_vars['product']->value['specific_prices'])&&$_smarty_tpl->tpl_vars['product']->value['specific_prices']&&isset($_smarty_tpl->tpl_vars['product']->value['specific_prices']['reduction'])&&$_smarty_tpl->tpl_vars['product']->value['specific_prices']['reduction']) {?>
                                                                            <span class="old-price product-price">
                                                                                    <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['displayWtPrice'][0][0]->displayWtPrice(array('p'=>$_smarty_tpl->tpl_vars['product']->value['price_without_reduction']),$_smarty_tpl);?>

                                                                            </span>

                                                                    <?php }?>
                                                            <?php }?>
                                                    </div>
                                                <?php }?>
                                            <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['hook'][0][0]->smartyHook(array('h'=>'displayProductListReviews','product'=>$_smarty_tpl->tpl_vars['product']->value),$_smarty_tpl);?>

                                        </div>
                                    </div>
                            </div>
                        </li>
                    <?php } ?>
                </ul>

            </div>
            <script type="text/javascript">
                    $(".tab-category-container-slider #tab_<?php echo $_smarty_tpl->tpl_vars['productCate']->value['id'];?>
 .productTabCategorySlider").bxSlider({
                        slideWidth:<?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['p_width']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['p_width'];?>
<?php } else { ?>270<?php }?>,
                        infiniteLoop: false,
                        slideMargin: 30,
                        minSlides: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['min_item']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['min_item'];?>
<?php } else { ?>1<?php }?>,
                        maxSlides: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['max_item']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['max_item'];?>
<?php } else { ?>3<?php }?>,
                        speed: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['speed_slide']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['speed_slide'];?>
<?php } else { ?>500<?php }?>,
                        pause: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['a_speed']!='') {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['a_speed'];?>
<?php } else { ?>1000<?php }?>,
                        controls: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['show_arrow']!=0) {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['show_arrow'];?>
<?php } else { ?>false<?php }?>,
                        pager: <?php if ($_smarty_tpl->tpl_vars['slideOptions']->value['show_ctr']!=0) {?><?php echo $_smarty_tpl->tpl_vars['slideOptions']->value['show_ctr'];?>
<?php } else { ?>false<?php }?>,
                    });
            </script>
        <?php } ?>	
    </div> <!-- .tab_container -->
</div>
            </div>
    </div>
</div>
<?php $_smarty_tpl->smarty->_tag_stack[] = array('addJsDefL', array('name'=>'min_item')); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]->addJsDefL(array('name'=>'min_item'), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>
<?php echo smartyTranslate(array('s'=>'Please select at least one product','js'=>1),$_smarty_tpl);?>
<?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]->addJsDefL(array('name'=>'min_item'), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_tag_stack);?>

<?php $_smarty_tpl->smarty->_tag_stack[] = array('addJsDefL', array('name'=>'max_item')); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]->addJsDefL(array('name'=>'max_item'), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>
<?php echo smartyTranslate(array('s'=>'You cannot add more than %d product(s) to the product comparison','sprintf'=>$_smarty_tpl->tpl_vars['comparator_max_item']->value,'js'=>1),$_smarty_tpl);?>
<?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['addJsDefL'][0][0]->addJsDefL(array('name'=>'max_item'), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_tag_stack);?>

<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['addJsDef'][0][0]->addJsDef(array('comparator_max_item'=>$_smarty_tpl->tpl_vars['comparator_max_item']->value),$_smarty_tpl);?>

<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['addJsDef'][0][0]->addJsDef(array('comparedProductsIds'=>$_smarty_tpl->tpl_vars['compared_products']->value),$_smarty_tpl);?>


<?php }} ?>
