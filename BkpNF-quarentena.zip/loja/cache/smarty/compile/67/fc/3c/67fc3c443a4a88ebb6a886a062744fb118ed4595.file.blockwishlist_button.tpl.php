<?php /* Smarty version Smarty-3.1.19, created on 2016-03-15 22:04:13
         compiled from "/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockwishlist/blockwishlist_button.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20859000156e8a2fd8665c7-16180466%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '67fc3c443a4a88ebb6a886a062744fb118ed4595' => 
    array (
      0 => '/var/www/html/nfsolucoesdigitais.com.br/web/loja/themes/pts_vela/modules/blockwishlist/blockwishlist_button.tpl',
      1 => 1455299876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20859000156e8a2fd8665c7-16180466',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_56e8a2fd87b478_41661795',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56e8a2fd87b478_41661795')) {function content_56e8a2fd87b478_41661795($_smarty_tpl) {?>


	
            <span class="wrap_bg">
            <i class="icon-heart icon-0x icon-mar-lr2"></i>
            <span class="wrap_text"><?php echo smartyTranslate(array('s'=>'Add to Wishlist','mod'=>'blockwishlist'),$_smarty_tpl);?>
</span>
            </span>
	<?php }} ?>
